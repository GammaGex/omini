document.addEventListener('DOMContentLoaded', async () => {
  // Elements
  const btnMinimize = document.getElementById('btnMinimize');
  const btnMaximize = document.getElementById('btnMaximize');
  const btnClose = document.getElementById('btnClose');

  const loginScreen = document.getElementById('loginScreen');
  const dashboardScreen = document.getElementById('dashboardScreen');

  const loginForm = document.getElementById('loginForm');
  const serverUrlInput = document.getElementById('serverUrl');
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const loginError = document.getElementById('loginError');
  const btnLogin = document.getElementById('btnLogin');

  const navUserName = document.getElementById('navUserName');
  const navUserRole = document.getElementById('navUserRole');
  const btnClearCache = document.getElementById('btnClearCache');
  const btnRefresh = document.getElementById('btnRefresh');
  const btnLogout = document.getElementById('btnLogout');
  const searchInput = document.getElementById('searchInput');
  const profileCount = document.getElementById('profileCount');
  const profilesTableBody = document.getElementById('profilesTableBody');

  let currentProfiles = [];
  let pollInterval = null;
  const proxyGeoCache = new Map();

  // Window Controls
  btnMinimize.addEventListener('click', () => window.gexApi.minimizeWindow());
  btnMaximize.addEventListener('click', () => window.gexApi.maximizeWindow());
  btnClose.addEventListener('click', () => window.gexApi.closeWindow());

  // 1. Auto-fill Saved Auth & Persistent Credentials
  const localSavedUser = localStorage.getItem('omnicloak_remember_username');
  const localSavedPass = localStorage.getItem('omnicloak_remember_password');

  const savedAuth = await window.gexApi.getSavedAuth();
  if (savedAuth) {
    if (savedAuth.serverUrl) serverUrlInput.value = savedAuth.serverUrl;
    if (savedAuth.username) usernameInput.value = savedAuth.username;
    if (savedAuth.password) passwordInput.value = savedAuth.password;
  }
  if (!usernameInput.value && localSavedUser) usernameInput.value = localSavedUser;
  if (!passwordInput.value && localSavedPass) passwordInput.value = localSavedPass;

  // 2. Login Submit
  let isLoggingIn = false;
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (isLoggingIn) return;
    isLoggingIn = true;
    loginError.style.display = 'none';
    const simAlert = document.getElementById('simultaneousAlert');
    if (simAlert) simAlert.style.display = 'none';

    const serverUrl = serverUrlInput.value.trim();
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();

    try {
      localStorage.setItem('omnicloak_remember_username', username);
      localStorage.setItem('omnicloak_remember_password', password);
    } catch(e) {}

    const btnText = btnLogin.querySelector('.btn-text');
    const btnSpinner = btnLogin.querySelector('.btn-spinner');
    btnText.style.display = 'none';
    btnSpinner.style.display = 'inline';
    btnLogin.disabled = true;

    try {
      const resp = await window.gexApi.login({ serverUrl, username, password });
      if (!resp.success) {
        loginError.textContent = resp.msg || 'Erro ao realizar login.';
        loginError.style.display = 'block';
        return;
      }

      // Login bem-sucedido
      showDashboard(resp.user);
    } catch (err) {
      loginError.textContent = 'Erro de conexão: ' + err.message;
      loginError.style.display = 'block';
    } finally {
      btnText.style.display = 'inline';
      btnSpinner.style.display = 'none';
      btnLogin.disabled = false;
      isLoggingIn = false;
    }
  });

  // 3. Show Dashboard
  function showDashboard(user) {
    loginScreen.style.display = 'none';
    dashboardScreen.style.display = 'flex';

    navUserName.textContent = user.name || user.username;
    const isAdmin = user && (user.role === 'ADMIN');
    navUserRole.textContent = isAdmin ? '👑 ADMIN' : '👤 USUÁRIO';

    // CONTROLE RIGOROSO: Apenas Administradores têm acesso a Políticas & Configurações

    loadProfiles();
    if (pollInterval) clearInterval(pollInterval);
    pollInterval = setInterval(loadProfiles, 8000);
  }

  // 4. Logout
  btnLogout.addEventListener('click', async () => {
    if (pollInterval) clearInterval(pollInterval);
    btnLogout.disabled = true;
    const oldText = btnLogout.innerText;
    btnLogout.innerText = 'Encerrando perfis...';
    try {
      await window.gexApi.logout();
    } finally {
      btnLogout.disabled = false;
      btnLogout.innerText = oldText;
      dashboardScreen.style.display = 'none';
      loginScreen.style.display = 'flex';
    }
  });

  // 5. Refresh
  btnRefresh.addEventListener('click', () => {
    loadProfiles();
  });

  // 5.1 Limpar Cache Local
  if (btnClearCache) {
    btnClearCache.addEventListener('click', async () => {
      if (!confirm('Deseja limpar todo o cache e arquivos temporários locais dos perfis?\n\nIsso resolve telas brancas e erros de carregamento sem alterar seu usuário e senha.')) {
        return;
      }
      const originalHtml = btnClearCache.innerHTML;
      try {
        btnClearCache.disabled = true;
        btnClearCache.innerHTML = `
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" class="spin">
            <line x1="12" y1="2" x2="12" y2="6"></line>
            <line x1="12" y1="18" x2="12" y2="22"></line>
            <line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line>
            <line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line>
            <line x1="2" y1="12" x2="6" y2="12"></line>
            <line x1="18" y1="12" x2="22" y2="12"></line>
            <line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line>
            <line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line>
          </svg>
          <span>Limpando...</span>
        `;
        const res = await window.gexApi.clearAllCache();
        if (res && res.success) {
          alert('Cache e arquivos temporários limpos com sucesso!\nVocê já pode iniciar os perfis normalmente.');
          loadProfiles();
        } else {
          alert('Aviso: ' + (res ? res.msg : 'Não foi possível concluir a limpeza'));
        }
      } catch (err) {
        alert('Erro ao limpar cache: ' + err.message);
      } finally {
        btnClearCache.disabled = false;
        btnClearCache.innerHTML = originalHtml;
      }
    });
  }

  // 6. Search Filter
  if (searchInput) searchInput.addEventListener('input', () => {
    renderProfilesTable();
  });

  // 7. Load Profiles
  async function loadProfiles() {
    try {
      const resp = await window.gexApi.getProfiles();
      if (resp.success) {
        currentProfiles = resp.profiles || [];
        renderProfilesTable();
      }
    } catch (e) {
      console.error('Erro ao carregar perfis:', e);
    }
  }

  // 8. Render Profiles Table
  function renderProfilesTable() {
    const term = (searchInput && searchInput.value) ? searchInput.value.trim().toLowerCase() : '';
    const filtered = currentProfiles.filter(p => {
      const name = (p.name || '').toLowerCase();
      return name.includes(term);
    });

    // Ordenação alfabética de A a Z
    filtered.sort((a, b) => (a.name || '').localeCompare(b.name || '', 'pt-BR', { sensitivity: 'base' }));

    profileCount.textContent = `${filtered.length} perfil(is) disponível(is)`;
    profilesTableBody.innerHTML = '';

    if (filtered.length === 0) {
      profilesTableBody.innerHTML = `
        <tr>
          <td colspan="5" style="text-align: center; padding: 40px; color: #64748b;">
            Nenhum perfil encontrado.
          </td>
        </tr>
      `;
      return;
    }

    filtered.forEach(p => {
      const tr = document.createElement('tr');

      // Status - Multi-Operador Concorrente
      let statusBadge = '';
      let actionBtn = '';

      if (p.isRunningLocally) {
        statusBadge = `
          <span class="status-pill status-running">
            <span class="pulse-dot-blue"></span>
            <span>Em execução</span>
          </span>
        `;
        actionBtn = `
          <button class="btn-stop" onclick="closeProfile(${p.serialNum})">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><rect x="5" y="5" width="14" height="14" rx="2"/></svg>
            <span>Fechar</span>
          </button>
        `;
      } else {
        statusBadge = `
          <span class="status-pill status-ready">
            <span class="pulse-dot-green"></span>
            <span>Pronto para uso</span>
          </span>
        `;
        actionBtn = `
          <button class="btn-launch" onclick="launchProfile(${p.serialNum})">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M7 5v14l12-7z"/></svg>
            <span>Iniciar</span>
          </button>
        `;
      }

      // Proxy
      const proxyHost = p.proxyHost || (p.proxy && p.proxy.host);
      const proxyPort = p.proxyPort || (p.proxy && p.proxy.port);
      const proxyUser = p.proxyUserName || (p.proxy && p.proxy.username);
      const proxyPass = p.proxyPasswd || (p.proxy && p.proxy.password);
      const proxyType = p.proxyType || (p.proxy && p.proxy.type) || 'HTTP';
      
      let geoBadge = '';
      if (proxyHost && proxyPort) {
        if (proxyGeoCache.has(p.id)) {
          const g = proxyGeoCache.get(p.id);
          geoBadge = `<div class="proxy-geo-line"><span class="geo-dot"></span><span>${g.ip} (${g.countryCode}) • ${g.timezone}</span></div>`;
        } else {
          // Consulta o IP em background silenciosamente
          setTimeout(async () => {
            try {
              const res = await window.gexApi.testProxy({ host: proxyHost, port: proxyPort, username: proxyUser, password: proxyPass });
              if (res && res.success && res.geo) {
                proxyGeoCache.set(p.id, res.geo);
                const el = document.getElementById(`proxy-sub-${p.id}`);
                if (el) el.innerHTML = `<span class="proxy-geo-line"><span class="geo-dot"></span><span>${res.geo.ip} (${res.geo.countryCode}) • ${res.geo.timezone}</span></span>`;
              }
            } catch (err) {}
          }, 300);
        }
      }

      function getProxyLabel(p, host) {
        if (p.proxy && p.proxy.name) return p.proxy.name;
        if (p.proxyName) return p.proxyName;
        if (p.proxyNote) return p.proxyNote;
        if (!host) return 'Sem Proxy';
        if (host.includes('webshare') || host.startsWith('23.230.')) return 'Webshare ISP';
        if (host.includes('oxylabs')) return 'Oxylabs Residencial';
        return 'Proxy Residencial';
      }

      const proxyInfo = proxyHost ? `
        <div class="proxy-cell">
          <div class="proxy-header-line">
            <span class="proxy-type-pill">${proxyType.toUpperCase()}</span>
            <span class="proxy-host-text">${proxyHost}:${proxyPort}</span>
          </div>
          <div id="proxy-sub-${p.id}" class="proxy-sub">${escapeHtml(getProxyLabel(p, proxyHost))}</div>
          ${geoBadge}
        </div>
      ` : '<span class="no-proxy">Sem Proxy</span>';

      tr.innerHTML = `
        <td class="profile-name-cell">
          <div style="font-weight: 700; font-size: 14px; color: #f8fafc; letter-spacing: 0.3px;">${escapeHtml(p.name)}</div>
        </td>
        <td>${proxyInfo}</td>
        <td>${statusBadge}</td>
        <td style="text-align: center;">${actionBtn}</td>
      `;

      profilesTableBody.appendChild(tr);
    });
  }

  // 9. Launch Action
  window.clearProfileCloudCache = async (profileId, name) => {
    if (!confirm(`Deseja realmente limpar todo o Cache e Sessão da Nuvem do perfil "${name}"?\n\nIsso apagará permanentemente cookies e arquivos de sessão salvos na nuvem. Ao reabrir, o perfil começará do zero (desconectado).`)) {
      return;
    }
    try {
      const res = await window.gexApi.clearProfileSession(profileId);
      if (res && res.success) {
        alert(`Cache e Sessão da Nuvem do perfil "${name}" foram limpos com sucesso!`);
        loadProfiles();
      } else {
        alert('Erro ao limpar cache da nuvem: ' + (res ? res.msg : 'Erro desconhecido'));
      }
    } catch (err) {
      alert('Erro: ' + err.message);
    }
  };

  const launchingSerialsUi = new Set();
  window.launchProfile = async (serialNum, ev) => {
    if (launchingSerialsUi.has(serialNum)) return;
    launchingSerialsUi.add(serialNum);

    const clickEv = ev || window.event;
    const btn = (clickEv && (clickEv.currentTarget || (clickEv.target && clickEv.target.closest('button')))) || null;
    if (btn) {
      btn.disabled = true;
      btn.textContent = '⏳ Abrindo...';
    }

    try {
      const resp = await window.gexApi.launchProfile(serialNum);
      if (!resp.success) {
        alert('Erro ao abrir perfil: ' + resp.msg);
      }
    } finally {
      launchingSerialsUi.delete(serialNum);
      loadProfiles();
    }
  };

  // 10. Close Action
  const closingSerialsUi = new Set();
  window.closeProfile = async (serialNum, ev) => {
    if (closingSerialsUi.has(serialNum)) return;
    closingSerialsUi.add(serialNum);

    const clickEv = ev || window.event;
    const btn = (clickEv && (clickEv.currentTarget || (clickEv.target && clickEv.target.closest('button')))) || null;
    if (btn) {
      btn.disabled = true;
      btn.textContent = '⏳ Fechando...';
    }

    try {
      await window.gexApi.closeProfile(serialNum);
    } finally {
      closingSerialsUi.delete(serialNum);
      loadProfiles();
    }
  };

  // 11. State change push
  window.gexApi.onProfileStateChange(() => {
    loadProfiles();
  });

  // 11.1 Sessão derrubada (login concorrente ou encerrada pelo admin)
  if (window.gexApi.onAuthKicked) {
    window.gexApi.onAuthKicked((kickData) => {
      try {
        const u = localStorage.getItem('omnicloak_remember_username');
        const p = localStorage.getItem('omnicloak_remember_password');
        if (u && !usernameInput.value) usernameInput.value = u;
        if (p && !passwordInput.value) passwordInput.value = p;
      } catch(e) {}
      if (pollInterval) clearInterval(pollInterval);
      if (dashboardScreen) dashboardScreen.style.display = 'none';
      if (loginScreen) loginScreen.style.display = 'flex';
      if (profilesTableBody) profilesTableBody.innerHTML = '';
      if (profileCount) profileCount.textContent = '0 perfil(is) disponível(is)';
      currentProfiles = [];

      const simultaneousAlert = document.getElementById('simultaneousAlert');
      const kickAlertIcon = document.getElementById('kickAlertIcon');
      const kickAlertTitle = document.getElementById('kickAlertTitle');
      const kickAlertMsg = document.getElementById('kickAlertMsg');

      const data = (typeof kickData === 'object' && kickData !== null) ? kickData : { msg: kickData };
      const reason = data.reason || '';

      let title = 'Acesso Simultâneo Identificado';
      let message = 'Sua conta foi conectada em outro computador.<br>Esta sessão foi desconectada automaticamente por segurança.';
      let icon = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>';

      const isAdminKick = reason === 'admin_forced' || 
                          reason === 'close_all_requested' || 
                          reason === 'session_cleared' || 
                          (data.msg && data.msg.toLowerCase().includes('administrador')) ||
                          (data.msg && data.msg.toLowerCase().includes('finalizada'));

      if (isAdminKick) {
        title = 'Sessão Encerrada pelo Administrador';
        message = (data.msg && data.msg.length > 5) ? data.msg : 'O Administrador encerrou a sua sessão ativa na Central OmniCloak.';
        icon = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>';
      } else if (data.title) {
        title = data.title;
        message = data.msg || message;
      }

      if (kickAlertIcon) kickAlertIcon.innerHTML = icon;
      if (kickAlertTitle) kickAlertTitle.textContent = title;
      if (kickAlertMsg) kickAlertMsg.innerHTML = message;
      if (simultaneousAlert) simultaneousAlert.style.display = 'block';
      if (loginError) loginError.style.display = 'none';
    });
  }

  // 12. Auto-Updater UI & Events
  const updateModal = document.getElementById('updateModal');
  const updateVersionText = document.getElementById('updateVersionText');
  const updateNotes = document.getElementById('updateNotes');
  const updateProgressContainer = document.getElementById('updateProgressContainer');
  const updateProgressBar = document.getElementById('updateProgressBar');
  const updateProgressText = document.getElementById('updateProgressText');
  const updateFooterActions = document.getElementById('updateFooterActions');
  const btnDismissUpdate = document.getElementById('btnDismissUpdate');
  const btnApplyUpdate = document.getElementById('btnApplyUpdate');
  const footerVersion = document.getElementById('footerVersion');
  const loginCheckUpdate = document.getElementById('loginCheckUpdate');
  const loginAppVersion = document.getElementById('loginAppVersion');

  let pendingDownloadUrl = null;

  // Atualiza versão real do executável no rodapé e na tela de login
  (async () => {
    try {
      const ver = await window.gexApi.getAppVersion();
      if (footerVersion) {
        footerVersion.innerHTML = `v${ver} (Windows & Mac) 🔄`;
      }
      if (loginAppVersion) {
        loginAppVersion.textContent = `OmniCloak v${ver}`;
      }
      if (loginCheckUpdate) {
        loginCheckUpdate.title = `Versão instalada: v${ver}. Clique para checar atualizações.`;
      }
    } catch(e) {}
  })();

  if (loginCheckUpdate) {
    loginCheckUpdate.addEventListener('click', async () => {
      loginCheckUpdate.textContent = 'Verificando...';
      await window.gexApi.checkForUpdates(true);
      setTimeout(() => { loginCheckUpdate.textContent = 'Checar atualizações'; }, 2000);
    });
  }

  if (footerVersion) {
    footerVersion.addEventListener('click', async () => {
      const orig = footerVersion.textContent;
      footerVersion.textContent = 'Verificando atualizações...';
      await window.gexApi.checkForUpdates(true);
      setTimeout(() => { footerVersion.textContent = orig; }, 2000);
    });
  }

  let isMandatoryUpdate = false;

  window.gexApi.onUpdateAvailable((data) => {
    pendingDownloadUrl = data.downloadUrl;
    isMandatoryUpdate = data.mandatory === true;
    updateVersionText.innerHTML = `Uma nova versão (<strong>${data.newVersion}</strong>) está disponível! (Você está na ${data.currentVersion})`;
    updateNotes.innerHTML = `<strong>Novidades da versão:</strong><br>${escapeHtml(data.releaseNotes)}`;
    updateProgressContainer.style.display = 'none';
    updateFooterActions.style.display = 'flex';

    if (isMandatoryUpdate) {
      btnDismissUpdate.style.display = 'inline-block';
      btnDismissUpdate.textContent = 'Fechar Aplicativo';
      btnDismissUpdate.style.background = '#ef4444';
      btnDismissUpdate.style.color = '#ffffff';
      btnDismissUpdate.style.borderColor = '#dc2626';
    } else {
      btnDismissUpdate.style.display = 'inline-block';
      btnDismissUpdate.textContent = 'Depois';
      btnDismissUpdate.style.background = '';
      btnDismissUpdate.style.color = '';
      btnDismissUpdate.style.borderColor = '';
    }

    updateModal.style.display = 'flex';
  });

  window.gexApi.onUpdateProgress((percent) => {
    updateProgressContainer.style.display = 'block';
    updateProgressBar.style.width = percent + '%';
    updateProgressText.textContent = `Baixando atualização: ${percent}%`;
  });

  window.gexApi.onUpdateUpToDate((data) => {
    alert(`Parabéns! O OmniCloak já está na versão mais recente (${data.currentVersion}).`);
  });

  btnDismissUpdate.addEventListener('click', () => {
    if (isMandatoryUpdate) {
      window.gexApi.closeWindow();
    } else {
      updateModal.style.display = 'none';
    }
  });

  btnApplyUpdate.addEventListener('click', async () => {
    const targetUrl = pendingDownloadUrl || 'https://gammacharts.online/gex/downloads/OmniCloak-Setup.exe';
    btnApplyUpdate.disabled = true;
    btnDismissUpdate.disabled = true;
    updateFooterActions.style.display = 'none';
    updateProgressContainer.style.display = 'block';
    updateProgressText.textContent = 'Iniciando download da atualização...';

    const resp = await window.gexApi.downloadAndInstallUpdate(targetUrl);
    if (!resp.success) {
      alert('Erro ao atualizar: ' + resp.msg);
      updateModal.style.display = 'none';
      btnApplyUpdate.disabled = false;
      btnDismissUpdate.disabled = false;
    } else if (resp.restarting) {
      updateProgressText.textContent = '✅ Atualização concluída! Reiniciando aplicativo...';
    } else {
      alert('Arquivo de atualização baixado com sucesso! Conclua a instalação substituindo o arquivo.');
      updateModal.style.display = 'none';
    }
  });

  function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  
});
