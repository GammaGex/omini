const { flipFuses, FuseVersion, FuseV1Options } = require('@electron/fuses');
const path = require('path');
const fs = require('fs');

module.exports = async function(context) {
  const { appOutDir, electronPlatformName, packager } = context;
  const productName = packager.appInfo.productFilename;

  let exePath;
  if (electronPlatformName === 'win32') {
    exePath = path.join(appOutDir, `${productName}.exe`);
  } else if (electronPlatformName === 'darwin') {
    exePath = path.join(appOutDir, `${productName}.app`, 'Contents', 'MacOS', productName);
  } else {
    exePath = path.join(appOutDir, productName);
  }

  if (!fs.existsSync(exePath)) {
    console.warn(`[FUSES] Warning: executable not found at ${exePath}`);
    return;
  }

  console.log(`[FUSES] Applying hardened Electron Fuses to: ${exePath}`);
  try {
    await flipFuses(exePath, {
      version: FuseVersion.V1,
      resetAdHocDarwinSignature: electronPlatformName === 'darwin',
      [FuseV1Options.RunAsNode]: false,
      [FuseV1Options.EnableCookieEncryption]: true,
      [FuseV1Options.EnableNodeOptionsEnvironmentVariable]: false,
      [FuseV1Options.EnableNodeCliInspectArguments]: false,
      [FuseV1Options.EnableEmbeddedAsarIntegrityValidation]: true,
      [FuseV1Options.OnlyLoadAppFromAsar]: true
    });
    console.log(`[FUSES] ✅ Hardened Electron Fuses successfully applied to ${productName}!`);
  } catch(err) {
    console.warn(`[FUSES] Warning: Failed to flip fuses on ${electronPlatformName}: ${err.message}`);
  }
};
