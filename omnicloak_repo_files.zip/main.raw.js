
const crypto = require('crypto');
const BUILD_SECRET = 'omni_shield_2026_9b82f7c014e35a9d';
const BUILD_VERSION = '1.3.4';
const COOKIE_SECRET = crypto.createHash('sha256').update(BUILD_SECRET + ':cookies:aes256').digest();

function decryptCookiesIfNeeded(cookiesData) {
  if (!cookiesData) return [];
  if (Array.isArray(cookiesData)) return cookiesData;
  if (typeof cookiesData === 'object' && cookiesData.encrypted === true && cookiesData.data) {
    try {
      const decipher = crypto.createDecipheriv('aes-256-gcm', COOKIE_SECRET, Buffer.from(cookiesData.iv, 'hex'));
      decipher.setAuthTag(Buffer.from(cookiesData.tag, 'hex'));
      let dec = decipher.update(cookiesData.data, 'hex', 'utf8');
      dec += decipher.final('utf8');
      const parsed = JSON.parse(dec);
      return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      console.error('[OmniCloak Shield] Erro ao descriptografar cookies:', e.message);
      return [];
    }
  }
  return [];
}


function getUnpackedExtensionId(extPath) {
  try {
    const crypto = require('crypto');
    const buf = Buffer.from(extPath, 'utf16le');
    const hash = crypto.createHash('sha256').update(buf).digest();
    return Array.from(hash.slice(0, 16)).map(b => {
      const high = (b >> 4) & 0x0f;
      const low = b & 0x0f;
      return String.fromCharCode(97 + high) + String.fromCharCode(97 + low);
    }).join('');
  } catch(e) {
    return null;
  }
}
function isChromeInternalSafePage(url) {
  if (!url) return true;
  const l = url.toLowerCase();
  return l === 'about:blank' ||
         l.startsWith('data:') ||
         l.startsWith('chrome://newtab') ||
         l.startsWith('chrome://new-tab-page') ||
         l.startsWith('chrome-untrusted://') ||
         l.startsWith('chrome://omnibox-popup') ||
         l.startsWith('chrome-extension://');
}

function isUrlBlocked(urlStr, blockedRules) {
  if (!urlStr || !Array.isArray(blockedRules) || blockedRules.length === 0) return false;
  const cleanUrl = String(urlStr).toLowerCase().trim();
  if (cleanUrl.startsWith('chrome://') || cleanUrl.startsWith('chrome-extension://') || cleanUrl.startsWith('about:')) return false;

  let parsed;
  try {
    parsed = new URL(cleanUrl);
  } catch(e) {
    return false;
  }

  const hostname = parsed.hostname;
  const pathname = parsed.pathname;
  const fullPathAndQuery = (parsed.pathname.replace(/\/+$/, '') || '/') + parsed.search;

  for (const raw of blockedRules) {
    if (!raw) continue;
    const rule = String(raw).toLowerCase().trim().replace(/^https?:\/\//i, '');
    if (!rule) continue;

    if (rule.includes('/')) {
      const slashIdx = rule.indexOf('/');
      const ruleHost = rule.substring(0, slashIdx);
      const rulePath = rule.substring(slashIdx);

      const hostMatch = (ruleHost === '*' || hostname === ruleHost || (ruleHost.startsWith('*.') && hostname.endsWith(ruleHost.slice(2))) || hostname.endsWith('.' + ruleHost));
      if (!hostMatch) continue;

      if (rulePath.includes('*')) {
        const regexStr = '^' + rulePath.split('*').map(s => s.replace(/[-/\\^$+?.()|[\]{}]/g, '\\$&')).join('.*');
        const reg = new RegExp(regexStr);
        if (reg.test(fullPathAndQuery) || reg.test(pathname) || reg.test(pathname + (parsed.search || '').toLowerCase())) {
          return true;
        }
      } else {
        const cleanRp = rulePath.replace(/\/+$/, '');
        if (fullPathAndQuery.startsWith(cleanRp) || pathname.startsWith(cleanRp)) {
          return true;
        }
      }
    } else {
      let domRule = rule.replace(/[:\/].*$/, '');
      if (domRule.startsWith('*.')) domRule = domRule.slice(2);
      if (hostname === domRule || hostname.endsWith('.' + domRule)) {
        return true;
      }
    }
  }
  return false;
}

function checkUrlForbidden(targetUrl, secRules = {}, bc = {}, pc = {}, teamPolicy = {}) {
  if (!targetUrl || isChromeInternalSafePage(targetUrl)) {
    return { blocked: false };
  }
  const lowerUrl = targetUrl.toLowerCase();

  // Autoridade única: Regras e Permissões definidas na Equipe
  const allowSettings = teamPolicy.allowSettings === true;
  const allowExtensions = teamPolicy.allowExtensions === true;
  const allowDevTools = teamPolicy.allowDevTools === true;
  const allowLan = teamPolicy.allowLan === true;

  // 1. Chrome Web Store & Instalação de Extensões
  if (!allowExtensions) {
    if (lowerUrl.includes('chromewebstore.google.com') || 
        lowerUrl.includes('chrome.google.com/webstore') || 
        lowerUrl.startsWith('chrome://extensions')) {
      return { blocked: true, reason: 'Acesso à Chrome Web Store e instalação de extensões estão bloqueados pela política da equipe.' };
    }
  }

  // 2. Configurações restritas do Chrome
  if (!allowSettings) {
    if (lowerUrl.startsWith('chrome://settings') || lowerUrl.startsWith('chrome://flags')) {
      return { blocked: true, reason: 'Páginas internas de configuração do Chrome estão restritas pelo Administrador para esta equipe.' };
    }
  }

  // 3. Janelas de DevTools
  if (!allowDevTools) {
    if (lowerUrl.startsWith('devtools://')) {
      return { blocked: true, reason: 'Ferramentas de desenvolvedor bloqueadas para esta equipe.' };
    }
  }

  // 4. Acesso à Rede Local (LAN)
  if (!allowLan) {
    if (lowerUrl.includes('localhost') || lowerUrl.includes('127.0.0.1') || lowerUrl.includes('192.168.') || lowerUrl.includes('10.') || lowerUrl.includes('172.16.')) {
      return { blocked: true, reason: 'Acesso a sites da rede local (LAN / Intranet) bloqueado pela política da equipe.' };
    }
  }

  // 5. Whitelist e Blacklist APLICAM-SE APENAS A SITES WEB (HTTP/HTTPS)
  if (lowerUrl.startsWith('http://') || lowerUrl.startsWith('https://')) {
    const isWhitelist = secRules.urlPolicyMode === 'whitelist' || teamPolicy.urlPolicyMode === 'whitelist';
    const isBlacklist = secRules.urlPolicyMode === 'blacklist' || teamPolicy.urlPolicyMode === 'blacklist';

    const blockedList = [
      ...(Array.isArray(secRules.blockedUrls) ? secRules.blockedUrls : []),
      ...(Array.isArray(teamPolicy.blockedUrls) ? teamPolicy.blockedUrls : [])
    ].filter(Boolean);

    // Bloqueios específicos de URLs/subpastas operam em ambos os modos
    if ((isWhitelist || isBlacklist) && blockedList.length > 0) {
      if (isUrlBlocked(targetUrl, blockedList)) {
        return { blocked: true, reason: 'Acesso a esta URL ou subpasta confidencial bloqueado pela política da equipe.' };
      }
    }

    if (isWhitelist) {
      const allowedList = [
        ...(Array.isArray(secRules.allowedUrls) ? secRules.allowedUrls : []),
        ...(Array.isArray(teamPolicy.allowedUrls) ? teamPolicy.allowedUrls : [])
      ].filter(Boolean);

      const isCoreGoogle = lowerUrl.includes('.gvt1.com') || lowerUrl.includes('.googleapis.com') || lowerUrl.includes('.gstatic.com') || lowerUrl.includes('.pki.goog');
      const hasYoutube = allowedList.some(a => a && a.toLowerCase().includes('youtube'));
      const isYoutubeCdn = hasYoutube && (
        lowerUrl.includes('ytimg.com') ||
        lowerUrl.includes('googlevideo.com') ||
        lowerUrl.includes('youtu.be') ||
        lowerUrl.includes('youtube-nocookie.com') ||
        lowerUrl.includes('ggpht.com') ||
        lowerUrl.includes('googleusercontent.com')
      );
      const hasIphey = allowedList.some(a => a && a.toLowerCase().includes('iphey'));
      const isIpheyCdn = hasIphey && (
        lowerUrl.includes('mixvisit.com') ||
        lowerUrl.includes('floppydata.com') ||
        lowerUrl.includes('prismic.io') ||
        lowerUrl.includes('cloudfront.net') ||
        lowerUrl.includes('jsdelivr.net') ||
        lowerUrl.includes('jsdelivr.com')
      );
      if (!isCoreGoogle && !isYoutubeCdn && !isIpheyCdn && allowedList.length > 0) {
        const isAllowed = allowedList.some(allowed => {
          if (!allowed || !allowed.trim()) return false;
          const clean = allowed.trim().replace(/^https?:\/\//i, '').replace(/[:\/].*$/, '').toLowerCase();
          return lowerUrl.includes(clean);
        });
        if (!isAllowed) {
          return { blocked: true, reason: 'Acesso a este site não autorizado. Este perfil/equipe opera sob Lista Branca estrita.' };
        }
      }
    }
  }

  return { blocked: false };
}

function applyChromeEnterprisePolicies(profile, settings, team) {
  if (process.platform !== 'win32') return;
  // Segurança e Isolamento: NUNCA gravar no Registro do Windows do usuário!
  // Políticas corporativas no Registro afetam o Chrome pessoal do usuário fora do OmniCloak.
  // Toda a proteção do OmniCloak (bloqueio de URLs, WebRTC, senhas, extensões) roda exclusivamente
  // isolada via flags do processo Chrome (--user-data-dir, --load-extension, OmniShield e CDP).
  try {
    const { execSync } = require('child_process');
    const baseKey = 'HKCU\\Software\\Policies\\Google\\Chrome';
    const hklmBase = 'HKLM\\Software\\Policies\\Google\\Chrome';
    const updateKey = 'HKCU\\Software\\Policies\\Google\\Update';

    // Limpa permanentemente quaisquer políticas legadas do Chrome e Update que tenham sido gravadas no sistema
    try { execSync('reg delete "' + baseKey + '" /f', { stdio: 'ignore' }); } catch(e) {}
    try { execSync('reg delete "' + hklmBase + '" /f', { stdio: 'ignore' }); } catch(e) {}
    try { execSync('reg delete "' + updateKey + '" /f', { stdio: 'ignore' }); } catch(e) {}
  } catch(e) {}
}

const { app, BrowserWindow, ipcMain, shell } = require('electron');

function omniLog(line) {
  try {
    const _fs = require('fs'), _path = require('path'), _os = require('os');
    let _d; try { _d = require('electron').app.getPath('userData'); } catch (e) { _d = _os.tmpdir(); }
    const _ld = _path.join(_d, 'logs');
    try { _fs.mkdirSync(_ld, { recursive: true }); } catch (e) {}
    _fs.appendFileSync(_path.join(_ld, 'omnicloak.log'), '[' + new Date().toISOString() + '] ' + line + '\n');
  } catch (e) {}
}
const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');
const https = require('https');
const net = require('net');
const { spawn, execSync } = require('child_process');
const WebSocket = require('ws');

let mainWindow = null;
let activeSessions = new Map(); // serialNum -> { proc, tunnelServer, heartbeatTimer, profileId }

// --- SINGLE INSTANCE LOCK: Impede abrir duas vezes ou logar múltiplos usuários simultâneos ---
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  omniLog('[OmniCloak Instance] Segunda instância detectada. Encerrando para evitar concorrência...');
  app.quit();
  process.exit(0);
}

app.on('second-instance', (event, commandLine, workingDirectory) => {
  omniLog('[OmniCloak Instance] Tentativa de segunda instância interceptada. Trazendo janela ativa para foco...');
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  }
});

let currentServerUrl = 'https://gammacharts.online/gex';
let API_KEY = '';
let currentUser = null;
let currentAuth = null;

function getAuthFilePath() {
  return path.join(app.getPath('userData'), 'auth.json');
}

function getCredentialsFilePath() {
  const dir = path.join(os.homedir(), '.omnicloak_profiles');
  if (!fs.existsSync(dir)) {
    try { fs.mkdirSync(dir, { recursive: true }); } catch(e) {}
  }
  return path.join(dir, 'saved_credentials.json');
}

function savePersistentCredentials(data) {
  try {
    const creds = {
      serverUrl: data.serverUrl || 'https://gammacharts.online/gex',
      username: data.username || '',
      password: data.password || '',
      updatedAt: new Date().toISOString()
    };
    fs.writeFileSync(getCredentialsFilePath(), JSON.stringify(creds, null, 2), 'utf8');
  } catch(e) {}
}

function loadPersistentCredentials() {
  try {
    const p = getCredentialsFilePath();
    if (fs.existsSync(p)) {
      return JSON.parse(fs.readFileSync(p, 'utf8'));
    }
  } catch(e) {}
  return null;
}

function loadSavedAuth() {
  let data = null;
  try {
    const p = getAuthFilePath();
    if (fs.existsSync(p)) {
      data = JSON.parse(fs.readFileSync(p, 'utf8'));
      if (data) {
        currentAuth = data;
        if (data.user) currentUser = data.user;
        if (data.user && data.user.apiKey) API_KEY = data.user.apiKey;
      }
    }
  } catch (e) {}

  // Fallback garantido: sempre preenche username e senha salvos se a sessão expirou ou após atualizações
  const creds = loadPersistentCredentials();
  if (creds) {
    if (!data) data = {};
    if (!data.username && creds.username) data.username = creds.username;
    if (!data.password && creds.password) data.password = creds.password;
    if (!data.serverUrl && creds.serverUrl) data.serverUrl = creds.serverUrl;
  }
  return data;
}

function saveAuth(data) {
  try {
    fs.writeFileSync(getAuthFilePath(), JSON.stringify(data, null, 2));
    if (data && data.username && data.password) {
      savePersistentCredentials({
        serverUrl: data.serverUrl,
        username: data.username,
        password: data.password
      });
    }
  } catch (e) {}
}

function clearSavedAuth() {
  try {
    const p = getAuthFilePath();
    if (fs.existsSync(p)) fs.unlinkSync(p);
  } catch (e) {}
}

async function closeAllActiveProfiles() {
  if (!activeSessions || activeSessions.size === 0) return;
  console.log(`[OmniCloak] Encerrando ${activeSessions.size} perfil(is) ativo(s) de forma coordenada...`);

  const sessions = Array.from(activeSessions.entries());

  // 1. Solicita fechamento limpo via CDP para salvar cookies e estado
  for (const [serial, session] of sessions) {
    try {
      if (session.heartbeatTimer) clearInterval(session.heartbeatTimer);
      if (session.cdpWs && session.cdpWs.readyState === WebSocket.OPEN) {
        try {
          session.cdpWs.send(JSON.stringify({ id: 9999, method: 'Browser.close' }));
        } catch(e) {}
      }
    } catch(e) {}
  }

  // 2. Breve janela para persistência de cookies pelo Chrome
  await new Promise(r => setTimeout(r, 600));

  // 3. Força encerramento dos processos restantes e notifica servidor
  for (const [serial, session] of sessions) {
    try {
      if (session.proc && !session.proc.killed) {
        try { session.proc.kill(); } catch(e) {}
      }
      if (session.tunnelServer) {
        try { session.tunnelServer.close(); } catch(e) {}
      }
      if (session.cdpWs) {
        try { session.cdpWs.terminate(); } catch(e) {}
      }
      if (session.profileId && session.userDataDir) {
        try { killChromeProcessesForProfile(session.profileId, session.userDataDir); } catch(e) {}
      }
      if (currentAuth && currentAuth.username && session.profileId) {
        try {
          await requestJson(`${currentServerUrl}/api/profiles/${session.profileId}/stop?user=${encodeURIComponent(currentAuth.username)}`, { method: 'POST' });
        } catch(e) {}
      }
    } catch(e) {}
  }

  activeSessions.clear();
  console.log('[OmniCloak] Todos os perfis ativos foram completamente finalizados.');
}

async function terminateCurrentAppSession(kickInfo = 'Acesso Simultâneo Identificado.') {
  await closeAllActiveProfiles();

  currentUser = null;
  currentAuth = null;
  clearSavedAuth();

  const kickData = (typeof kickInfo === 'string') 
    ? { msg: kickInfo, reason: kickInfo.toLowerCase().includes('administrador') ? 'admin_forced' : 'another_device_login' }
    : (kickInfo || {});

  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send('auth:kicked', kickData);
  }
}

function requestJson(url, options = {}) {
  return new Promise((resolve, reject) => {
    const isHttps = url.startsWith('https');
    const client = isHttps ? https : http;
    const reqHeaders = Object.assign({}, options.headers || {});
    if (API_KEY && url.indexOf('/api/') !== -1) {
      reqHeaders['x-api-key'] = API_KEY;
    }
    if (currentAuth && currentAuth.appSessionToken) {
      reqHeaders['x-app-session-token'] = currentAuth.appSessionToken;
    }
    if (currentAuth && currentAuth.username) {
      reqHeaders['x-operator-user'] = currentAuth.username;
    }

    // --- Shield: HMAC Signature & Payload Encryption Handshake ---
    if (url.indexOf('/api/') !== -1) {
      const timestamp = Date.now().toString();
      let pathPart = '';
      try {
        const u = new URL(url);
        pathPart = u.pathname;
      } catch {
        pathPart = url.replace(/^https?:\/\/[^\/]+/, '').split('?')[0];
      }
      const sig = crypto.createHmac('sha256', BUILD_SECRET)
        .update(`${BUILD_VERSION}:${timestamp}:${pathPart}`)
        .digest('hex');
      reqHeaders['x-build-version'] = BUILD_VERSION;
      reqHeaders['x-build-timestamp'] = timestamp;
      reqHeaders['x-build-signature'] = sig;
      reqHeaders['x-encrypted-payload'] = '1';
    }

    options = Object.assign({}, options, { headers: reqHeaders });

    const req = client.request(url, options, (res) => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          // Somente derruba o aplicativo se for retorno de autenticação de conta (/api/auth/)
          const isAuthEndpoint = url.includes('/api/auth/');
          
          if (parsed && (res.statusCode === 426 || parsed.code === 426) && parsed.data && parsed.data.updateRequired) {
            if (mainWindow && !mainWindow.isDestroyed()) {
              mainWindow.webContents.send('updater:available', {
                currentVersion: app.getVersion(),
                newVersion: '1.2.8',
                releaseNotes: parsed.msg || 'Nova atualização obrigatória disponível.',
                mandatory: true,
                downloadUrl: parsed.data.downloadUrl || 'https://gammacharts.online/gex/downloads/OmniCloak-Setup.exe'
              });
            }
          }

          const isAccountKick = parsed && (parsed.reason === 'another_device_login' || parsed.reason === 'admin_forced' || (parsed.code === 409 && parsed.msg && parsed.msg.includes('outro computador')));
          if (isAuthEndpoint && (parsed.kicked === true || isAccountKick)) {
            const reason = parsed.reason || (parsed.data && parsed.data.reason) || (parsed.msg && parsed.msg.includes('Administrador') ? 'admin_forced' : 'another_device_login');
            const kickMsg = (parsed.msg && parsed.msg !== 'success' ? parsed.msg : null) || (parsed.data && parsed.data.msg && parsed.data.msg !== 'success' ? parsed.data.msg : null) || 'Sua sessão foi encerrada.';
            terminateCurrentAppSession({ msg: kickMsg, reason });
          }
          resolve(parsed);
        } catch (e) {
          reject(new Error(`Resposta inválida: ${body.substring(0, 100)}`));
        }
      });
    });
    req.on('error', reject);
    if (options.body) {
      req.write(typeof options.body === 'string' ? options.body : JSON.stringify(options.body));
    }
    req.end();
  });
}

function getChromeExecutable() {
  if (process.platform === 'darwin') {
    const macPaths = [
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser',
      path.join(os.homedir(), 'Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
    ];
    for (const p of macPaths) if (fs.existsSync(p)) return p;
  } else if (process.platform === 'win32') {
    const winPaths = [
      'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
      'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
      path.join(process.env.LOCALAPPDATA || '', 'Google\\Chrome\\Application\\chrome.exe')
    ];
    for (const p of winPaths) if (fs.existsSync(p)) return p;
  } else {
    const linuxPaths = ['/usr/bin/google-chrome', '/usr/bin/chromium-browser'];
    for (const p of linuxPaths) if (fs.existsSync(p)) return p;
  }
  throw new Error(`Google Chrome não encontrado neste computador (${process.platform}). Por favor, instale o Google Chrome.`);
}

function getInstalledChromeVersion(chromePath) {
  try {
    if (!chromePath) return null;
    const dir = path.dirname(chromePath);
    if (fs.existsSync(dir)) {
      const entries = fs.readdirSync(dir);
      for (const e of entries) {
        if (/^\d+\.\d+\.\d+\.\d+$/.test(e)) {
          return e;
        }
      }
    }
  } catch(e) {}
  return null;
}

function startLocalProxyTunnel(targetHost, targetPort, username, password, filterPolicy) {
  return new Promise((resolve) => {
    const authHeader = (username && password) ? ('Basic ' + Buffer.from(username + ':' + password).toString('base64')) : null;

    const blockedHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Acesso Bloqueado pela Equipe</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0b0f19; color: #f8fafc; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
    .card { background: #1e293b; border: 1px solid rgba(239, 68, 68, 0.4); border-radius: 12px; padding: 36px; text-align: center; max-width: 500px; box-shadow: 0 20px 40px rgba(0,0,0,0.6); }
    .icon { font-size: 52px; margin-bottom: 14px; }
    h2 { margin: 0 0 10px 0; color: #ef4444; font-size: 20px; }
    p { margin: 0; color: #94a3b8; font-size: 14px; line-height: 1.6; }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">🛑</div>
    <h2>Acesso Bloqueado pela Política da Equipe</h2>
    <p>O destino que você tentou acessar não é permitido para este perfil ou equipe operacional.</p>
  </div>
</body>
</html>`;

    function isForbidden(host) {
      if (!host) return false;
      const lower = host.toLowerCase();
      if (lower === 'ip-api.com' || lower.endsWith('.ip-api.com')) return false;
      if (!filterPolicy) return false;

      if (filterPolicy.blockWebStore) {
        if (lower.includes('chromewebstore.google.com') || lower.includes('chrome.google.com')) {
          return true;
        }
      }

      if (filterPolicy.blockLan) {
        if (lower === 'localhost' || lower === '127.0.0.1' || lower.startsWith('192.168.') || lower.startsWith('10.') || lower.startsWith('172.16.')) {
          return true;
        }
      }

      if (filterPolicy.whitelist && filterPolicy.whitelist.length > 0) {
        const isCoreGoogle = lower.endsWith('.gvt1.com') || lower.endsWith('.googleapis.com') || lower.endsWith('.gstatic.com') || lower.endsWith('.pki.goog');
        const hasYoutube = filterPolicy.whitelist.some(u => u && u.toLowerCase().includes('youtube'));
        const isYoutubeCdn = hasYoutube && (
          lower === 'ytimg.com' || lower.endsWith('.ytimg.com') ||
          lower === 'googlevideo.com' || lower.endsWith('.googlevideo.com') ||
          lower === 'youtu.be' || lower.endsWith('.youtu.be') ||
          lower === 'youtube-nocookie.com' || lower.endsWith('.youtube-nocookie.com') ||
          lower === 'ggpht.com' || lower.endsWith('.ggpht.com') ||
          lower === 'googleusercontent.com' || lower.endsWith('.googleusercontent.com')
        );
        const hasIphey = filterPolicy.whitelist.some(u => u && u.toLowerCase().includes('iphey'));
        const isIpheyCdn = hasIphey && (
          lower === 'mixvisit.com' || lower.endsWith('.mixvisit.com') ||
          lower === 'floppydata.com' || lower.endsWith('.floppydata.com') ||
          lower === 'prismic.io' || lower.endsWith('.prismic.io') ||
          lower === 'cloudfront.net' || lower.endsWith('.cloudfront.net') ||
          lower === 'jsdelivr.net' || lower.endsWith('.jsdelivr.net') ||
          lower === 'jsdelivr.com' || lower.endsWith('.jsdelivr.com')
        );
        if (!isCoreGoogle && !isYoutubeCdn && !isIpheyCdn) {
          const allowed = filterPolicy.whitelist.some(u => {
            if (!u || !u.trim()) return false;
            const clean = u.trim().replace(/^https?:\/\//i, '').replace(/[:\/].*$/, '').toLowerCase();
            return lower === clean || lower.endsWith('.' + clean);
          });
          if (!allowed) return true;
        }
      }

      if (filterPolicy.blacklist && filterPolicy.blacklist.length > 0) {
        const blocked = filterPolicy.blacklist.some(u => {
          if (!u || !u.trim()) return false;
          const clean = u.trim().replace(/^https?:\/\//i, '').replace(/[:\/].*$/, '').toLowerCase();
          return lower === clean || lower.endsWith('.' + clean);
        });
        if (blocked) return true;
      }

      return false;
    }

    const server = http.createServer((req, res) => {
      const hostHeader = (req.headers.host || '').split(':')[0].toLowerCase();
      if (isForbidden(hostHeader)) {
        res.writeHead(403, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(blockedHtml);
        return;
      }

      if (targetHost && targetPort) {
        const options = {
          host: targetHost,
          port: Number(targetPort),
          path: req.url,
          method: req.method,
          headers: authHeader ? { ...req.headers, 'Proxy-Authorization': authHeader } : req.headers
        };
        const proxyReq = http.request(options, proxyRes => {
          res.writeHead(proxyRes.statusCode, proxyRes.headers);
          proxyRes.pipe(res);
        });
        proxyReq.on('error', () => { res.writeHead(502); res.end(); });
        req.pipe(proxyReq);
      } else {
        res.writeHead(404);
        res.end();
      }
    });

    server.on('connect', (req, clientSocket, head) => {
      const parts = req.url.split(':');
      const targetServerHost = parts[0].toLowerCase();
      const targetServerPort = Number(parts[1] || 443);

      if (isForbidden(targetServerHost)) {
        console.log('[OmniCloak Tunnel] BLOQUEADO pelo filtro de URL:', targetServerHost);
        clientSocket.write('HTTP/1.1 403 Forbidden\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\n\r\n' + blockedHtml);
        clientSocket.destroy();
        return;
      }

      if (targetHost && targetPort) {
        const proxySocket = net.connect(Number(targetPort), targetHost, () => {
          let connectReq = `CONNECT ${targetServerHost}:${targetServerPort} HTTP/1.1\r\n` +
            `Host: ${targetServerHost}:${targetServerPort}\r\n` +
            (authHeader ? `Proxy-Authorization: ${authHeader}\r\n` : '') +
            `Proxy-Connection: Keep-Alive\r\n\r\n`;

          proxySocket.write(connectReq);
          if (head && head.length > 0) proxySocket.write(head);
        });

        let buffer = '';
        const onConnectData = (chunk) => {
          buffer += chunk.toString('latin1');
          const headerEnd = buffer.indexOf('\r\n\r\n');
          if (headerEnd !== -1) {
            proxySocket.removeListener('data', onConnectData);
            if (buffer.startsWith('HTTP/1.1 200') || buffer.startsWith('HTTP/1.0 200')) {
              clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
              const remaining = buffer.substring(headerEnd + 4);
              if (remaining.length > 0) clientSocket.write(Buffer.from(remaining, 'latin1'));
              proxySocket.pipe(clientSocket);
              clientSocket.pipe(proxySocket);
            } else {
              clientSocket.destroy();
              proxySocket.destroy();
            }
          }
        };
        proxySocket.on('data', onConnectData);

        proxySocket.setTimeout(25000, () => {
          try { proxySocket.destroy(); clientSocket.destroy(); } catch(e) {}
        });
        clientSocket.setTimeout(35000, () => {
          try { clientSocket.destroy(); proxySocket.destroy(); } catch(e) {}
        });
        proxySocket.on('error', () => { try { clientSocket.destroy(); } catch(e) {} });
        clientSocket.on('error', () => { try { proxySocket.destroy(); } catch(e) {} });
      } else {
        const directSocket = net.connect(targetServerPort, targetServerHost, () => {
          clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
          if (head && head.length > 0) directSocket.write(head);
          directSocket.pipe(clientSocket);
          clientSocket.pipe(directSocket);
        });
        directSocket.setTimeout(25000, () => {
          try { directSocket.destroy(); clientSocket.destroy(); } catch(e) {}
        });
        directSocket.on('error', () => { try { clientSocket.destroy(); } catch(e) {} });
        clientSocket.on('error', () => { try { directSocket.destroy(); } catch(e) {} });
      }
    });

    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      resolve({ server, port });
    });
  });
}

const COUNTRY_LOCALES = {
  BR: { lang: 'pt-BR', accept: 'pt-BR,pt,en-US,en', languages: ['pt-BR', 'pt', 'en-US', 'en'] },
  US: { lang: 'en-US', accept: 'en-US,en', languages: ['en-US', 'en'] },
  GB: { lang: 'en-GB', accept: 'en-GB,en', languages: ['en-GB', 'en'] },
  CA: { lang: 'en-CA', accept: 'en-CA,en,fr-CA', languages: ['en-CA', 'en', 'fr-CA'] },
  DE: { lang: 'de-DE', accept: 'de-DE,de,en', languages: ['de-DE', 'de', 'en'] },
  FR: { lang: 'fr-FR', accept: 'fr-FR,fr,en', languages: ['fr-FR', 'fr', 'en'] },
  ES: { lang: 'es-ES', accept: 'es-ES,es,en', languages: ['es-ES', 'es', 'en'] },
  PT: { lang: 'pt-PT', accept: 'pt-PT,pt,en-US,en', languages: ['pt-PT', 'pt', 'en'] },
  IT: { lang: 'it-IT', accept: 'it-IT,it,en', languages: ['it-IT', 'it', 'en'] },
  NL: { lang: 'nl-NL', accept: 'nl-NL,nl,en', languages: ['nl-NL', 'nl', 'en'] }
};

function getLocaleForCountry(code) {
  if (code && COUNTRY_LOCALES[code.toUpperCase()]) {
    return COUNTRY_LOCALES[code.toUpperCase()];
  }
  return COUNTRY_LOCALES.US;
}

async function resolveProxyGeo(proxyHost, proxyPort, proxyUser, proxyPass) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => resolve(null), 8500);
    const options = {
      host: proxyHost,
      port: Number(proxyPort),
      path: 'http://ip-api.com/json',
      timeout: 8000
    };
    if (proxyUser && proxyPass) {
      options.headers = {
        'Proxy-Authorization': 'Basic ' + Buffer.from(`${proxyUser}:${proxyPass}`).toString('base64'),
        'Host': 'ip-api.com'
      };
    }
    http.get(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        clearTimeout(timeout);
        try {
          const json = JSON.parse(data);
          if (json.status === 'success') {
            resolve({
              ip: json.query,
              country: json.country,
              countryCode: json.countryCode,
              timezone: json.timezone || 'America/Sao_Paulo',
              lat: json.lat || -23.5505,
              lon: json.lon || -46.6333,
              city: json.city || ''
            });
            return;
          }
        } catch (e) {}
        resolve(null);
      });
    }).on('error', () => {
      clearTimeout(timeout);
      resolve(null);
    });
  });
}

function resolveGeoViaTunnel(tunnelPort) {
  return new Promise((resolve) => {
    if (!tunnelPort) return resolve(null);
    const timeout = setTimeout(() => resolve(null), 8500);
    try {
      const req = http.get({ host: '127.0.0.1', port: tunnelPort, path: 'http://ip-api.com/json', headers: { 'Host': 'ip-api.com' }, timeout: 8000 }, (res) => {
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
          clearTimeout(timeout);
          try { const j = JSON.parse(data); if (j && j.status === 'success') { resolve({ ip: j.query, country: j.country, countryCode: j.countryCode, timezone: j.timezone, lat: j.lat, lon: j.lon, city: j.city }); return; } } catch (e) {}
          resolve(null);
        });
      });
      req.on('error', () => { clearTimeout(timeout); resolve(null); });
      req.on('timeout', () => { try { req.destroy(); } catch (e) {} clearTimeout(timeout); resolve(null); });
    } catch (e) { clearTimeout(timeout); resolve(null); }
  });
}

function resolveDirectGeo() {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => resolve(null), 4500);
    try {
      const req = http.get('http://ip-api.com/json', { timeout: 4000 }, (res) => {
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
          clearTimeout(timeout);
          try {
            const j = JSON.parse(data);
            if (j && j.status === 'success') {
              resolve({ ip: j.query, country: j.country, countryCode: j.countryCode, timezone: j.timezone, lat: j.lat, lon: j.lon, city: j.city });
              return;
            }
          } catch(e) {}
          resolve(null);
        });
      });
      req.on('error', () => { clearTimeout(timeout); resolve(null); });
      req.on('timeout', () => { try { req.destroy(); } catch (e) {} clearTimeout(timeout); resolve(null); });
    } catch(e) { clearTimeout(timeout); resolve(null); }
  });
}

function generateStealthScript(config, geoData, browserTag = null, tagRule = 'prefix', blockedUrls = [], policy = {}) {
  const cores = Number((config && (config.hardwareConcurrency || config.cores))) || 8;
  const memory = Number((config && (config.deviceMemory || config.memory))) || 16;
  const v = (config && config.webglVendor) || "Google Inc. (NVIDIA)";
  const r = (config && config.webglRenderer) || "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0)";
  const sw = Number((config && config.screenResolution ? String(config.screenResolution).split('x')[0] : '1920')) || 1920;
  const sh = Number((config && config.screenResolution ? String(config.screenResolution).split('x')[1] : '1080')) || 1080;

  let seedNum = 0;
  const seedStr = String((config && (config.canvasSeed || config.profileId || config.id)) || 'omnicloak_seed_default');
  for (let i = 0; i < seedStr.length; i++) {
    seedNum = ((seedNum << 5) - seedNum) + seedStr.charCodeAt(i);
    seedNum |= 0;
  }
  seedNum = Math.abs(seedNum) || 12345;

  const isIntel = r.toLowerCase().includes('intel');
  const isAmd = r.toLowerCase().includes('amd') || r.toLowerCase().includes('radeon');
  const gpuInfo = isIntel ? {
    vendor: "intel",
    architecture: "gen-12lp",
    device: "Intel(R) UHD Graphics 770",
    description: "Intel(R) UHD Graphics 770 Direct3D12"
  } : (isAmd ? {
    vendor: "amd",
    architecture: "rdna-2",
    device: "AMD Radeon RX 6600",
    description: "AMD Radeon RX 6600 Direct3D12"
  } : {
    vendor: "nvidia",
    architecture: "ampere",
    device: "NVIDIA GeForce RTX 3060",
    description: "NVIDIA GeForce RTX 3060 Direct3D12"
  });

  const HEAVY = !!(policy && policy.heavyMask === true);
  return `
(function() {
  'use strict';
  try {
    if (window.__omniStealthInjected) return;
    window.__omniStealthInjected = true;
    const __H = ${HEAVY};

    // --- 1. NATIVE FUNCTION & METHOD CAMOUFLAGE (Bypasses CreepJS, Iphey, Bot Scanners) ---
    const nativeFunctions = new Set();
    const origToString = Function.prototype.toString;

    const customToString = function() {
      if (nativeFunctions.has(this) || (this && this._isNative)) {
        return 'function ' + (this.name || '') + '() { [native code] }';
      }
      return origToString.apply(this, arguments);
    };
    nativeFunctions.add(customToString);

    try {
      if (__H) Object.defineProperty(Function.prototype, 'toString', {
        value: customToString,
        configurable: true,
        writable: true
      });
    } catch(e) {}

    const makeIndistinguishableGetter = (targetObject, prop, valueFn) => {
      const getter = {
        ['get ' + prop]() {
          if (typeof window !== 'undefined' && this !== targetObject && !(this instanceof targetObject.constructor)) {
            throw new TypeError('Illegal invocation');
          }
          return valueFn();
        }
      }['get ' + prop];
      nativeFunctions.add(getter);
      return getter;
    };

    const makeIndistinguishableMethod = (name, fn) => {
      const method = {
        [name](...args) {
          return fn.apply(this, args);
        }
      }[name];
      nativeFunctions.add(method);
      return method;
    };

    // --- 2. ELIMINATION OF CDP LEAKS (console.context / automation) ---
    try { delete console.context; } catch(e) {}
    if ('context' in console) {
      try {
        Object.defineProperty(console, 'context', {
          get: () => undefined,
          set: () => {},
          configurable: true
        });
      } catch(e) {}
    }

    ${Array.isArray(blockedUrls) && blockedUrls.length > 0 ? `
    // 0. OmniCloak Shield: Bloqueio Instantâneo In-Page (0ms, Sem Flash)
    try {
      var __omniBlockedRules = ${JSON.stringify(blockedUrls)};
      
      function __checkUrlBlocked(target) {
        if (!target) return false;
        try {
          var p = new URL(target, window.location.href);
          var h = p.hostname.toLowerCase();
          var path = p.pathname.toLowerCase();
          var fpq = (path.replace(/\\/+$/, '') || '/') + p.search.toLowerCase();

          for (var i = 0; i < __omniBlockedRules.length; i++) {
            var raw = (__omniBlockedRules[i] || '').toLowerCase().trim().replace(/^https?:\\/\\//i, '');
            if (!raw) continue;
            if (raw.includes('/')) {
              var sIdx = raw.indexOf('/');
              var rh = raw.substring(0, sIdx);
              var rp = raw.substring(sIdx);
              var hm = (rh === '*' || h === rh || (rh.startsWith('*.') && h.endsWith(rh.slice(2))) || h.endsWith('.' + rh));
              if (!hm) continue;
              if (rp.includes('*')) {
                var rx = '^' + rp.split('*').map(function(s) { return s.replace(/[-/\\\\^$+?.()|[\]{}]/g, '\\\\$&'); }).join('.*');
                var reg = new RegExp(rx);
                if (reg.test(fpq) || reg.test(path) || reg.test(path + p.search.toLowerCase())) return true;
              } else {
                var cleanRp = rp.replace(/\\/+$/, '');
                if (fpq.startsWith(cleanRp) || path.startsWith(cleanRp)) return true;
              }
            } else {
              var dr = raw.replace(/[:\\/].*$/, '');
              if (dr.startsWith('*.')) dr = dr.slice(2);
              if (h === dr || h.endsWith('.' + dr)) return true;
            }
          }
        } catch(e) {}
        return false;
      }

      function __omniShowBlocked(urlTarget) {
        try {
          var targetStr = String(urlTarget || window.location.pathname || window.location.href);
          var overlayId = 'omnicloak-block-overlay';
          var existing = document.getElementById(overlayId);
          if (!existing) {
            existing = document.createElement('div');
            existing.id = overlayId;
            existing.style.cssText = 'position:fixed !important;top:0 !important;left:0 !important;right:0 !important;bottom:0 !important;width:100vw !important;height:100vh !important;background:#0b0f19 !important;color:#f8fafc !important;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif !important;display:flex !important;align-items:center !important;justify-content:center !important;z-index:2147483647 !important;margin:0 !important;padding:20px !important;box-sizing:border-box !important;overflow:auto !important;';
            
            var isCurrentUrlBlocked = __checkUrlBlocked(window.location.href);
            var safeHomeUrl = window.location.origin + '/';
            
            var cardHtml = '<div style="background:#161f30;border:2px solid #ef4444;border-radius:16px;padding:36px;text-align:center;max-width:520px;width:90%;box-shadow:0 25px 60px rgba(0,0,0,0.85);box-sizing:border-box;margin:auto;">'
              + '<div style="font-size:56px;margin-bottom:14px;line-height:1;">🚫</div>'
              + '<h2 style="margin:0 0 10px 0;color:#ef4444;font-size:24px;font-weight:800;letter-spacing:-0.5px;">Acesso Bloqueado</h2>'
              + '<p style="margin:0 0 16px 0;color:#94a3b8;font-size:14px;line-height:1.5;">Esta página e suas configurações confidenciais estão bloqueadas pela política de segurança da sua equipe.</p>'
              + '<div style="background:#0f172a;border:1px solid #334155;color:#f87171;font-family:monospace;font-size:12px;padding:10px 14px;border-radius:6px;word-break:break-all;margin-bottom:24px;display:block;width:100%;box-sizing:border-box;text-align:left;"><strong>URL Bloqueada:</strong> <span id="omnicloak-blocked-span"></span></div>'
              + '<div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">'
              + '<button id="omnicloak-btn-home" style="background:#2563eb;color:#ffffff;border:none;padding:13px 26px;border-radius:8px;font-weight:700;cursor:pointer;font-size:14px;transition:background 0.2s;display:inline-block;text-decoration:none;">🏠 Voltar para a Página Inicial</button>'
              + (!isCurrentUrlBlocked ? '<button id="omnicloak-btn-close" style="background:#334155;color:#f8fafc;border:none;padding:13px 20px;border-radius:8px;font-weight:700;cursor:pointer;font-size:14px;transition:background 0.2s;">✕ Fechar</button>' : '')
              + '</div></div>';
            
            existing.innerHTML = cardHtml;
            (document.body || document.documentElement).appendChild(existing);
            
            var btnHome = document.getElementById('omnicloak-btn-home');
            if (btnHome) {
              btnHome.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                window.location.replace(safeHomeUrl);
              };
            }
            var btnClose = document.getElementById('omnicloak-btn-close');
            if (btnClose) {
              btnClose.onclick = function(e) {
                e.preventDefault();
                e.stopPropagation();
                existing.remove();
              };
            }
          }
          var span = document.getElementById('omnicloak-blocked-span');
          if (span) span.textContent = targetStr;
        } catch(e) {}
      }

      function __omniHideBlocked() {
        try {
          var existing = document.getElementById('omnicloak-block-overlay');
          if (existing) existing.remove();
        } catch(e) {}
      }

      setInterval(function() {
        try {
          if (__checkUrlBlocked(window.location.href)) {
            __omniShowBlocked(window.location.href);
          } else {
            __omniHideBlocked();
          }
        } catch(e) {}
      }, 100);

      try {
        var hideStyle = document.createElement('style');
        hideStyle.id = 'omnicloak-hide-links';
        hideStyle.innerHTML = 'a[href*="/user/settings"], a[href*="/preferences"], a[href*="/account-settings"], a[href*="/subscription"], a[href*="action=payments"], a[href*="action=subscriptions"], [data-menu-item*="settings"], [data-menu-item*="accessibility"] { display: none !important; pointer-events: none !important; }';
        (document.head || document.documentElement).appendChild(hideStyle);
      } catch(e) {}

      if (__checkUrlBlocked(window.location.href)) {
        __omniShowBlocked(window.location.href);
      }

      window.addEventListener('click', function(e) {
        try {
          var el = e.target;
          while (el && el !== document) {
            if (el.tagName === 'A' && el.href) {
              if (__checkUrlBlocked(el.href)) {
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                __omniShowBlocked(el.href);
                return false;
              }
            }
            var attrUrl = el.getAttribute('data-href') || el.getAttribute('to') || el.getAttribute('href');
            if (attrUrl && __checkUrlBlocked(attrUrl)) {
              e.preventDefault();
              e.stopPropagation();
              e.stopImmediatePropagation();
              __omniShowBlocked(attrUrl);
              return false;
            }
            var text = (el.innerText || el.textContent || '').trim().toLowerCase();
            if (el.getAttribute('role') === 'menuitem' || (el.className && typeof el.className === 'string' && el.className.includes('Menu-item')) || el.tagName === 'BUTTON') {
              if (text === 'settings' || text === 'configurações' || text === 'accessibility' || text === 'acessibilidade' || text.includes('accessibility') || text.includes('settings')) {
                var currentOrigin = window.location.origin;
                if (currentOrigin.includes('quantdata.us') || currentOrigin.includes('spotgamma.com') || currentOrigin.includes('menthorq.com')) {
                  e.preventDefault();
                  e.stopPropagation();
                  e.stopImmediatePropagation();
                  __omniShowBlocked(currentOrigin + '/user/settings/general');
                  return false;
                }
              }
            }
            el = el.parentElement;
          }
        } catch(err) {}
      }, true);

      var origPush = (window.History && window.History.prototype && window.History.prototype.pushState) || history.pushState;
      var patchPush = function(state, unused, url) {
        if (url && __checkUrlBlocked(url)) {
          console.warn('[OmniCloak Block] Rota bloqueada:', url);
          __omniShowBlocked(url);
          return;
        }
        return origPush.apply(this, arguments);
      };
      history.pushState = patchPush;
      try { window.History.prototype.pushState = patchPush; } catch(e) {}

      var origReplace = (window.History && window.History.prototype && window.History.prototype.replaceState) || history.replaceState;
      var patchReplace = function(state, unused, url) {
        if (url && __checkUrlBlocked(url)) {
          console.warn('[OmniCloak Block] Rota bloqueada:', url);
          __omniShowBlocked(url);
          return;
        }
        return origReplace.apply(this, arguments);
      };
      history.replaceState = patchReplace;
      try { window.History.prototype.replaceState = patchReplace; } catch(e) {}
    } catch(e) {}
    ` : ''}

    // 1. Tag Visual do Perfil na Aba
    ${browserTag ? `
    try {
      var origTitleDesc = Object.getOwnPropertyDescriptor(Document.prototype, 'title');
      if (origTitleDesc && origTitleDesc.set) {
        var cleanTag = ${JSON.stringify(browserTag)};
        var tagRule = ${JSON.stringify(tagRule)};
        var applyTag = function(t) {
          if (!t) return '[' + cleanTag + ']';
          if (t.includes('[' + cleanTag + ']') || t.includes('(' + cleanTag + ')')) return t;
          return tagRule === 'suffix' ? (t + ' [' + cleanTag + ']') : ('[' + cleanTag + '] ' + t);
        };
        Object.defineProperty(document, 'title', {
          get: function() { return origTitleDesc.get.call(this); },
          set: function(val) { origTitleDesc.set.call(this, applyTag(val)); },
          configurable: true
        });
        if (document.title) document.title = applyTag(document.title);
      }
    } catch(e) {}
    ` : ''}

    // 2. WebGL Fingerprint Cloaking (Coherent WebKit vendor, spoofed unmasked vendor/renderer)
    const v = ${JSON.stringify(v)};
    const r = ${JSON.stringify(r)};

    const patchGL = function(proto) {
      if (!proto) return;
      const origGetParam = proto.getParameter;
      proto.getParameter = makeIndistinguishableMethod('getParameter', function(param) {
        if (param === 7936) return 'WebKit';
        if (param === 7937) return 'WebKit WebGL';
        if (param === 37445) return v;
        if (param === 37446) return r;
        return origGetParam.apply(this, arguments);
      });

      const origGetExt = proto.getExtension;
      proto.getExtension = makeIndistinguishableMethod('getExtension', function(name) {
        const ext = origGetExt.apply(this, arguments);
        if (name === 'WEBGL_debug_renderer_info') {
          return ext || { UNMASKED_VENDOR_WEBGL: 37445, UNMASKED_RENDERER_WEBGL: 37446 };
        }
        return ext;
      });
    };

    if (__H) patchGL(typeof WebGLRenderingContext !== 'undefined' ? WebGLRenderingContext.prototype : null);
    if (__H) patchGL(typeof WebGL2RenderingContext !== 'undefined' ? WebGL2RenderingContext.prototype : null);

    // 2b. WebGPU Architecture Spoofing (Coherent with WebGL GPU)
    try {
      if (__H && typeof navigator !== 'undefined' && navigator.gpu && navigator.gpu.requestAdapter) {
        const origRequestAdapter = navigator.gpu.requestAdapter;
        navigator.gpu.requestAdapter = makeIndistinguishableMethod('requestAdapter', async function() {
          try {
            const adapter = await origRequestAdapter.apply(this, arguments);
            if (!adapter) return null;
            return new Proxy(adapter, {
              get(target, prop, receiver) {
                if (prop === 'info') return ${JSON.stringify(gpuInfo)};
                if (prop === 'requestAdapterInfo') {
                  return makeIndistinguishableMethod('requestAdapterInfo', () => Promise.resolve(${JSON.stringify(gpuInfo)}));
                }
                const val = Reflect.get(target, prop, receiver);
                if (typeof val === 'function') {
                  return val.bind(target);
                }
                return val;
              }
            });
          } catch(e) {
            return null;
          }
        });
      }
    } catch(e) {}

    // 3. Hardware Concurrency & Device Memory (Navigator.prototype ONLY - No own property leak)
    try {
      const coresGetter = makeIndistinguishableGetter(Navigator.prototype, 'hardwareConcurrency', () => ${cores});
      const memGetter = makeIndistinguishableGetter(Navigator.prototype, 'deviceMemory', () => ${memory});
      if (__H) Object.defineProperty(Navigator.prototype, 'hardwareConcurrency', { get: coresGetter, configurable: true, enumerable: true });
      if (__H) Object.defineProperty(Navigator.prototype, 'deviceMemory', { get: memGetter, configurable: true, enumerable: true });
    } catch(e) {}

    // 3b. Worker & Blob Hardware Shield (Shields Blob Workers from leaking host hardware)
    try {
      const OrigBlob = window.Blob;
      const workerStealthHook = 'try { if (typeof WorkerGlobalScope !== "undefined" && self.navigator) { const navProto = Object.getPrototypeOf(self.navigator); if (navProto) { Object.defineProperty(navProto, "hardwareConcurrency", { get: () => ' + ${cores} + ', configurable: true }); Object.defineProperty(navProto, "deviceMemory", { get: () => ' + ${memory} + ', configurable: true }); } } } catch(e) {}';

      if (__H) window.Blob = function(parts, options) {
        if (options && (options.type === 'application/javascript' || options.type === 'text/javascript' || (options.type && options.type.includes('javascript')))) {
          if (Array.isArray(parts)) {
            parts = [workerStealthHook + '\\n', ...parts];
          }
        }
        return new OrigBlob(parts, options);
      };
      window.Blob.prototype = OrigBlob.prototype;
      nativeFunctions.add(window.Blob);
    } catch(e) {}

    // 4. Screen Resolution (Screen.prototype ONLY)
    ${(HEAVY && config && config.screenResolution && config.screenResolution !== 'real') ? `
    try {
      const wGetter = makeIndistinguishableGetter(Screen.prototype, 'width', () => ${sw});
      const hGetter = makeIndistinguishableGetter(Screen.prototype, 'height', () => ${sh});
      const awGetter = makeIndistinguishableGetter(Screen.prototype, 'availWidth', () => ${sw});
      const ahGetter = makeIndistinguishableGetter(Screen.prototype, 'availHeight', () => ${sh - 40});

      Object.defineProperty(Screen.prototype, 'width', { get: wGetter, configurable: true, enumerable: true });
      Object.defineProperty(Screen.prototype, 'height', { get: hGetter, configurable: true, enumerable: true });
      Object.defineProperty(Screen.prototype, 'availWidth', { get: awGetter, configurable: true, enumerable: true });
      Object.defineProperty(Screen.prototype, 'availHeight', { get: ahGetter, configurable: true, enumerable: true });
    } catch(e) {}
    ` : ''}

    // 5. Deterministic & Idempotent Canvas Noise
    ${(HEAVY && config && (config.canvas === 'noise' || config.canvasNoise !== false || config.canvasSeed)) ? `
    try {
      const seed = ${seedNum};
      const canvasesNoiseApplied = new WeakSet();

      function applyStableCanvasNoise(canvas) {
        if (!canvas || canvasesNoiseApplied.has(canvas)) return;
        try {
          const ctx = canvas.getContext('2d');
          if (ctx && canvas.width > 0 && canvas.height > 0) {
            const imgData = ctx.getImageData(0, 0, Math.min(16, canvas.width), Math.min(16, canvas.height));
            if (imgData && imgData.data && imgData.data.length >= 4) {
              const pixelIdx = ((seed % 15) * 4);
              imgData.data[pixelIdx] = (imgData.data[pixelIdx] ^ 1);
              ctx.putImageData(imgData, 0, 0);
            }
          }
        } catch(e) {}
        canvasesNoiseApplied.add(canvas);
      }

      const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
      HTMLCanvasElement.prototype.toDataURL = makeIndistinguishableMethod('toDataURL', function() {
        applyStableCanvasNoise(this);
        return origToDataURL.apply(this, arguments);
      });

      const origToBlob = HTMLCanvasElement.prototype.toBlob;
      HTMLCanvasElement.prototype.toBlob = makeIndistinguishableMethod('toBlob', function() {
        applyStableCanvasNoise(this);
        return origToBlob.apply(this, arguments);
      });

      const origGetImageData = CanvasRenderingContext2D.prototype.getImageData;
      CanvasRenderingContext2D.prototype.getImageData = makeIndistinguishableMethod('getImageData', function() {
        if (this.canvas) applyStableCanvasNoise(this.canvas);
        return origGetImageData.apply(this, arguments);
      });
    } catch(e) {}
    ` : ''}

    // 6. Deterministic & Idempotent AudioContext Noise
    ${(HEAVY && config && (config.audio === 'noise' || config.audioNoise !== false)) ? `
    try {
      const audioBuffersApplied = new WeakSet();
      const audioOffset = ((${seedNum} % 10) + 1) * 0.0000001;

      if (typeof AudioBuffer !== 'undefined') {
        const origGetChannelData = AudioBuffer.prototype.getChannelData;
        AudioBuffer.prototype.getChannelData = makeIndistinguishableMethod('getChannelData', function() {
          const data = origGetChannelData.apply(this, arguments);
          if (data && data.length > 32 && !audioBuffersApplied.has(this)) {
            for (let i = 0; i < data.length; i += 100) {
              data[i] += audioOffset;
            }
            audioBuffersApplied.add(this);
          }
          return data;
        });
      }
    } catch(e) {}
    ` : ''}

    ${policy && policy.preventTampering === true ? `
    // Anti-Tampering (Bloqueio de F12, Inspecionar Elemento, Atalhos de Dev e Código-fonte)
    try {
      window.addEventListener('keydown', function(e) {
        if (e.keyCode === 123 || e.key === 'F12') {
          e.preventDefault(); e.stopPropagation(); return false;
        }
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.keyCode === 73 || e.key === 'I' || e.key === 'i')) {
          e.preventDefault(); e.stopPropagation(); return false;
        }
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.keyCode === 74 || e.key === 'J' || e.key === 'j')) {
          e.preventDefault(); e.stopPropagation(); return false;
        }
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.keyCode === 67 || e.key === 'C' || e.key === 'c')) {
          e.preventDefault(); e.stopPropagation(); return false;
        }
        if ((e.ctrlKey || e.metaKey) && (e.keyCode === 85 || e.key === 'U' || e.key === 'u')) {
          e.preventDefault(); e.stopPropagation(); return false;
        }
      }, true);

      window.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        e.stopPropagation();
        return false;
      }, true);
    } catch(e) {}
    ` : ''}

    ${policy && policy.disableVideos === true ? `
    // Desativação total de Vídeos
    try {
      var vStyle = document.createElement('style');
      vStyle.id = 'omnicloak-disable-videos';
      vStyle.innerHTML = 'video { display: none !important; pointer-events: none !important; visibility: hidden !important; }';
      (document.head || document.documentElement).appendChild(vStyle);

      setInterval(function() {
        try {
          var vids = document.querySelectorAll('video');
          for (var i = 0; i < vids.length; i++) {
            if (!vids[i].paused) vids[i].pause();
          }
        } catch(e) {}
      }, 500);
    } catch(e) {}
    ` : ''}

  } catch(e) {}
})();
`;
}

function buildClientStealthExtension(extDir, profile, geoData, browserTag = null, tagRule = 'prefix', team = null) {
  if (!fs.existsSync(extDir)) fs.mkdirSync(extDir, { recursive: true });
  const fp = profile.fingerprint || profile.config || {};
  const effectiveBlocked = [
    ...(Array.isArray(profile.security && profile.security.blockedUrls) ? profile.security.blockedUrls : []),
    ...(Array.isArray(team && team.browserPolicy && team.browserPolicy.blockedUrls) ? team.browserPolicy.blockedUrls : [])
  ].map(s => String(s || '').trim()).filter(Boolean);
  const stealthCode = generateStealthScript(fp, geoData, browserTag, tagRule, effectiveBlocked, (team && team.browserPolicy) || {});
  fs.writeFileSync(path.join(extDir, 'stealth.js'), stealthCode);

  const manifest = {
    manifest_version: 3,
    name: "OmniCloak Stealth Engine",
    version: "1.0.0",
    description: "Anti-detect engine for OmniCloak",
    permissions: ["webRequest", "webRequestAuthProvider"],
    host_permissions: ["<all_urls>"],
    content_scripts: [
      {
        matches: ["<all_urls>"],
        js: ["stealth.js"],
        run_at: "document_start",
        world: "MAIN"
      }
    ],
    background: { service_worker: "background.js" }
  };
  fs.writeFileSync(path.join(extDir, 'manifest.json'), JSON.stringify(manifest, null, 2));
  fs.writeFileSync(path.join(extDir, 'background.js'), '// OmniCloak Background Service\n');
}

function downloadFile(url, dstPath) {
  return new Promise((resolve, reject) => {
    const proto = url.startsWith('https') ? https : http;
    const req = proto.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return downloadFile(res.headers.location, dstPath).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`Falha no download (HTTP ${res.statusCode})`));
      }
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        try {
          fs.writeFileSync(dstPath, Buffer.concat(chunks));
          resolve();
        } catch(e) {
          reject(e);
        }
      });
      res.on('error', reject);
    });
    req.on('error', reject);
  });
}

async function syncProfileExtensions(groupNames, serverUrl, apiKey) {
  const targetGroups = (Array.isArray(groupNames) ? groupNames : [groupNames])
    .map(g => String(g || '').trim().toLowerCase())
    .filter(Boolean);
  if (targetGroups.length === 0) return [];

  const effectiveApiKey = apiKey || (currentAuth && (currentAuth.apiKey || (currentAuth.user && currentAuth.user.apiKey))) || '';
  const extBaseDir = path.join(app.getPath('userData'), 'extensions');
  if (!fs.existsSync(extBaseDir)) fs.mkdirSync(extBaseDir, { recursive: true });

  const listUrl = `${serverUrl}/api/extensions?_t=${Date.now()}`;
  let extensions = [];
  try {
    const resp = await requestJson(listUrl);
    extensions = (resp && resp.data) || [];
    omniLog('syncExt: fetch OK total=' + extensions.length);
  } catch (e) {
    console.error('[OmniCloak] Falha ao obter lista de extensões da nuvem:', e.message);
    return [];
  }

  const matched = extensions.filter(e => {
    if (e.enabled === false) return false;
    const eId = String(e.id || '').toLowerCase();
    const eName = String(e.name || '').toLowerCase();
    const eFolder = String(e.folderName || '').toLowerCase();
    // Match direto por ID, Nome ou Pasta atribuídos diretamente ao perfil
    if (targetGroups.some(t => t === eId || t === eName || t === eFolder)) return true;
    // Match por grupo
    if (Array.isArray(e.groups)) {
      return e.groups.some(g => {
        const gl = String(g || '').trim().toLowerCase();
        return targetGroups.includes(gl) || gl === 'all' || gl === 'todos' || gl === 'geral';
      });
    }
    return false;
  });

  omniLog('syncExt: matched=' + matched.length + ' | targetGroups=' + JSON.stringify(targetGroups) + ' | matchedNames=' + JSON.stringify(matched.map(m=>m.name)));
  const finalExtDirs = [];

  for (const ext of matched) {
    const extFolder = path.join(extBaseDir, ext.folderName || ext.id);
    const manifestFile = path.join(extFolder, 'manifest.json');
    const versionLockFile = path.join(extFolder, '.version_lock');
    const remoteVer = String(ext.version || '') + '_' + String(ext.updatedAt || '');

    let needDownload = !fs.existsSync(manifestFile);
    if (!needDownload && fs.existsSync(versionLockFile)) {
      try {
        const localVer = fs.readFileSync(versionLockFile, 'utf8').trim();
        if (localVer !== remoteVer) needDownload = true;
      } catch(e) {}
    } else if (!needDownload) {
      needDownload = true;
    }

    // Se o manifest.json não existir ou a extensão foi atualizada na nuvem, baixa e descompacta
    if (needDownload) {
      try {
        console.log(`[OmniCloak] Sincronizando extensão atualizada "${ext.name}" (${ext.id})...`);
        const zipFile = path.join(app.getPath('temp'), `${ext.id}.zip`);
        const downloadUrl = `${serverUrl}/api/extensions/${ext.id}/download?apiKey=${effectiveApiKey}`;

        await downloadFile(downloadUrl, zipFile);
        omniLog('syncExt: baixou zip ' + ext.id + ' de ' + downloadUrl);

        if (!fs.existsSync(extFolder)) fs.mkdirSync(extFolder, { recursive: true });
        if (process.platform === 'win32') {
          const psCmd = `powershell -NoProfile -Command "Expand-Archive -LiteralPath '${zipFile}' -DestinationPath '${extFolder}' -Force"`;
          execSync(psCmd, { stdio: 'ignore' });
        } else {
          execSync(`unzip -q -o "${zipFile}" -d "${extFolder}"`, { stdio: 'ignore' });
        }

        try { if (fs.existsSync(zipFile)) fs.unlinkSync(zipFile); } catch(e) {}
        try { fs.writeFileSync(versionLockFile, remoteVer); } catch(e) {}
        omniLog('syncExt: extraiu ' + ext.id + ' | manifestExiste=' + fs.existsSync(manifestFile) + ' | pasta=' + extFolder);
      } catch (dlErr) {
        omniLog('syncExt: ERRO download/extract ' + ext.id + ': ' + dlErr.message);
        console.error(`[OmniCloak] Erro ao sincronizar extensão "${ext.name}":`, dlErr.message);
      }
    }

    if (fs.existsSync(manifestFile)) {
      finalExtDirs.push(extFolder);
    } else {
      // Caso tenha descompactado com uma pasta interna
      try {
        const subItems = fs.readdirSync(extFolder);
        for (const item of subItems) {
          const sub = path.join(extFolder, item);
          if (fs.statSync(sub).isDirectory() && fs.existsSync(path.join(sub, 'manifest.json'))) {
            finalExtDirs.push(sub);
            break;
          }
        }
      } catch(e) {}
    }
  }

  omniLog('syncExt: FINAL dirs=' + JSON.stringify(finalExtDirs));
  return finalExtDirs;
}

// ==========================================
// AUTO-UPDATER ENGINE
// ==========================================

function isNewerVersion(remote, local) {
  const pRemote = remote.replace(/[^0-9.]/g, '').split('.').map(Number);
  const pLocal = local.replace(/[^0-9.]/g, '').split('.').map(Number);
  for (let i = 0; i < Math.max(pRemote.length, pLocal.length); i++) {
    const r = pRemote[i] || 0;
    const l = pLocal[i] || 0;
    if (r > l) return true;
    if (r < l) return false;
  }
  return false;
}

async function checkAppUpdates(isManual = false) {
  try {
    const versionUrl = `${currentServerUrl}/version.json?_t=${Date.now()}`;
    const remoteInfo = await requestJson(versionUrl);
    const currentVer = app.getVersion();

    if (remoteInfo && remoteInfo.version && isNewerVersion(remoteInfo.version, currentVer)) {
      let downloadUrl = remoteInfo.downloadUrl;
      if (remoteInfo.downloads) {
        if (process.platform === 'darwin') {
          downloadUrl = process.arch === 'arm64' ? remoteInfo.downloads.mac_arm64 : remoteInfo.downloads.mac_x64;
        } else {
          downloadUrl = remoteInfo.downloads.win || downloadUrl;
        }
      }
      if (!downloadUrl) downloadUrl = `${currentServerUrl}/downloads/OmniCloak-Setup.exe`;
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('updater:available', {
          currentVersion: currentVer,
          newVersion: remoteInfo.version,
          releaseNotes: remoteInfo.releaseNotes || 'Melhorias de estabilidade e novas camuflagens.',
          mandatory: remoteInfo.mandatory === true,
          downloadUrl
        });
      }
      return { updateAvailable: true, newVersion: remoteInfo.version };
    } else {
      if (isManual && mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('updater:upToDate', { currentVersion: currentVer });
      }
      return { updateAvailable: false, currentVersion: currentVer };
    }
  } catch (err) {
    console.error('[Updater] Erro ao checar atualizações:', err.message);
    if (isManual && mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('updater:error', { msg: err.message });
    }
    return { error: err.message };
  }
}

function createWindow() {
  // Carrega URL da nuvem do cache se houver
  const saved = loadSavedAuth();
  if (saved && saved.serverUrl) {
    currentServerUrl = saved.serverUrl.replace(/\/$/, '');
  }

  mainWindow = new BrowserWindow({
    width: 1260,
    height: 820,
    minWidth: 980,
    minHeight: 620,
    frame: false,
    titleBarStyle: 'hidden',
    backgroundColor: '#0a0d14',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));

  mainWindow.webContents.on('did-finish-load', () => {
    setTimeout(() => {
      checkAppUpdates(false);
    }, 1200);
  });
}


// Migração transparente de pastas de perfil de .gexcloud_profiles para .omnicloak_profiles
try {
  const oldProfDir = path.join(os.homedir(), '.gexcloud_profiles');
  const newProfDir = path.join(os.homedir(), '.omnicloak_profiles');
  if (fs.existsSync(oldProfDir) && !fs.existsSync(newProfDir)) {
    fs.renameSync(oldProfDir, newProfDir);
  }
} catch(e) {}

app.whenReady().then(() => {
  createWindow();

  // Verificação periódica suave em background a cada 3 horas (evita incomodar o operador durante o expediente)
  setInterval(() => {
    checkAppUpdates(false);
  }, 3 * 60 * 60 * 1000);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('before-quit', () => {
  for (const [serial, session] of activeSessions.entries()) {
    try {
      if (session.proc && !session.proc.killed) session.proc.kill();
      if (session.tunnelServer) session.tunnelServer.close();
      if (session.heartbeatTimer) clearInterval(session.heartbeatTimer);
    } catch(e) {}
  }
  activeSessions.clear();
});

app.on('window-all-closed', () => {
  for (const [serial, session] of activeSessions.entries()) {
    try {
      if (session.proc) session.proc.kill();
      if (session.tunnelServer) session.tunnelServer.close();
      if (session.heartbeatTimer) clearInterval(session.heartbeatTimer);
    } catch(e) {}
  }
  activeSessions.clear();
  if (process.platform !== 'darwin') app.quit();
});

// IPC HANDLERS
ipcMain.handle('auth:getSaved', async () => {
  return loadSavedAuth();
});

ipcMain.handle('auth:login', async (event, { serverUrl, username, password }) => {
  try {
    currentServerUrl = (serverUrl || 'https://gammacharts.online/gex').replace(/\/$/, '');
    const resp = await requestJson(`${currentServerUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: { username, password }
    });

    if (resp.code !== 0 || !resp.data) {
      return { success: false, msg: resp.msg || 'Credenciais inválidas' };
    }

    currentUser = resp.data;
    API_KEY = resp.data.apiKey || '';
    const appSessionToken = resp.data.appSessionToken || '';
    currentAuth = { serverUrl: currentServerUrl, username, password, user: currentUser, appSessionToken };
    saveAuth(currentAuth);

    return { success: true, user: currentUser };
  } catch (err) {
    return { success: false, msg: `Erro ao conectar no servidor: ${err.message}` };
  }
});

ipcMain.handle('auth:logout', async () => {
  console.log('[OmniCloak Logout] Botão Sair acionado. Fechando todos os perfis e navegadores...');
  await closeAllActiveProfiles();

  if (currentAuth && currentAuth.username) {
    try {
      await requestJson(`${currentServerUrl}/api/auth/logout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: { username: currentAuth.username }
      });
    } catch(e) {}
  }
  currentUser = null;
  currentAuth = null;
  clearSavedAuth();
  return { success: true };
});

// Monitor contínuo de sessão única: se o usuário logar em outro computador ou for derrubado pelo admin
setInterval(async () => {
  if (currentAuth && currentAuth.username && currentAuth.appSessionToken) {
    try {
      const q = `user=${encodeURIComponent(currentAuth.username)}&token=${encodeURIComponent(currentAuth.appSessionToken)}`;
      const check = await requestJson(`${currentServerUrl}/api/auth/heartbeat?${q}`);
      if (check && (check.kicked === true || (check.data && check.data.kicked === true))) {
        const reason = check.reason || (check.data && check.data.reason) || (check.msg && check.msg.includes('Administrador') ? 'admin_forced' : 'another_device_login');
        const msg = (check.msg && check.msg !== 'success' ? check.msg : null) || (check.data && check.data.msg && check.data.msg !== 'success' ? check.data.msg : null) || 'Acesso Simultâneo Identificado.';
        console.log(`[OmniCloak Session Kick] ${reason} - ${msg}`);
        terminateCurrentAppSession({ msg, reason });
      }
    } catch (e) {}
  }
}, 20 * 1000); // 20 segundos (detecta login concorrente em tempo real)

ipcMain.handle('profiles:list', async () => {
  if (!currentAuth) return { success: false, msg: 'Não autenticado' };
  try {
    const resp = await requestJson(`${currentServerUrl}/api/profiles?user=${encodeURIComponent(currentAuth.username)}`);
    const list = (resp.data && resp.data.list) || [];
    
    const mapped = list.map(p => ({
      ...p,
      isRunningLocally: activeSessions.has(p.serialNum)
    }));

    return { success: true, profiles: mapped };
  } catch (err) {
    return { success: false, msg: err.message };
  }
});

const launchingSerials = new Set();
function killChromeProcessesForProfile(profileId, userDataDir) {
  if (!userDataDir) return;
  try {
    if (process.platform === 'win32') {
      const cleanPath = userDataDir.replace(/\\/g, '\\\\');
        const psCmd = `Get-CimInstance Win32_Process -Filter "Name = 'chrome.exe'" | Where-Object { $_.CommandLine -like "*${cleanPath}*" -or $_.CommandLine -like "*profile_${profileId}*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`;
      const { spawnSync } = require('child_process');
      spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', psCmd], { timeout: 4000 });
    } else {
      const { spawnSync } = require('child_process');
      spawnSync('pkill', ['-9', '-f', userDataDir], { timeout: 3000 });
    }
  } catch(e) {
    console.warn('[OmniCloak] Aviso ao encerrar processos anteriores do Chrome:', e.message);
  }

  // Remove travas Singleton do Chrome para evitar reuso de sessão em memória
  try {
    const singletonFiles = ['SingletonLock', 'SingletonCookie', 'SingletonSocket', 'lockfile'];
    for (const sf of singletonFiles) {
      const sp = path.join(userDataDir, sf);
      if (fs.existsSync(sp)) {
        try { fs.unlinkSync(sp); } catch(e) {}
      }
    }
  } catch(e) {}
}

ipcMain.handle('profile:launch', async (event, serialNum) => {
  if (!currentAuth) return { success: false, msg: 'Não autenticado' };
  if (launchingSerials.has(serialNum) || activeSessions.has(serialNum)) {
    return { success: false, msg: 'Este perfil já está iniciando ou em execução neste computador.' };
  }
  launchingSerials.add(serialNum);

  try {
    let latestCookies = [];
    let cookiePollTimer = null;
    let activeCdpWs = null;

    const profilesResp = await requestJson(`${currentServerUrl}/api/profiles?user=${encodeURIComponent(currentAuth.username)}`);
    const profileList = (profilesResp.data && profilesResp.data.list) || [];
    const profile = profileList.find(p => String(p.serialNum) === String(serialNum));
    if (!profile) return { success: false, msg: 'Perfil não encontrado.' };

    // 1. Obtém dados de inicialização da Nuvem (Suporte multi-operador simultâneo)
    const startResp = await requestJson(`${currentServerUrl}/api/profiles/${profile.id}/start?user=${encodeURIComponent(currentAuth.username)}`);
    if (startResp.code !== 0 || !startResp.data) {
      return { success: false, msg: `Erro ao iniciar perfil: ${startResp.msg || 'Perfil indisponível'}` };
    }

    const { profile: liveProfile, proxy, chromeArgs, settings: globalSettings, team: teamData } = startResp.data;
    const bc = (teamData && teamData.browserPolicy) || {}; // policy unica: Equipe
    const ds = (globalSettings && globalSettings.dataSync) || {};
    const pc = (globalSettings && globalSettings.profileConfig) || {};
    const sec = liveProfile.security || {};
    const teamPolicy = (teamData && teamData.browserPolicy) || {};

    // Autoridade única: Políticas e Permissões regidas estritamente pela Equipe
    const allowSettings = teamPolicy.allowSettings === true;
    const allowExtensions = teamPolicy.allowExtensions === true;
    const allowDevTools = teamPolicy.allowDevTools === true;
    const allowLan = teamPolicy.allowLan === true;

    const effectiveUrlMode = teamPolicy.urlPolicyMode || 'none';
    const effectiveWhitelist = Array.isArray(teamPolicy.allowedUrls) ? teamPolicy.allowedUrls : [];
    const effectiveBlacklist = Array.isArray(teamPolicy.blockedUrls) ? teamPolicy.blockedUrls : [];

    const filterPolicy = {
      blockWebStore: !allowExtensions,
      blockLan: !allowLan,
      whitelist: effectiveUrlMode === 'whitelist' ? effectiveWhitelist : null,
      blacklist: effectiveUrlMode === 'blacklist' ? effectiveBlacklist : null
    };

    // 2. Túnel local para proxy com filtro integrado de URL e extensões
    let tunnelServer = null;
    let localProxyArg = null;
    let tunnelPort = null;
    const pHost = (proxy && proxy.host) || liveProfile.proxyHost;
    const pPort = (proxy && proxy.port) || liveProfile.proxyPort;
    const pUser = (proxy && proxy.username) || liveProfile.proxyUserName;
    const pPass = (proxy && proxy.password) || liveProfile.proxyPasswd;

    try {
      const tunnel = await startLocalProxyTunnel(pHost, pPort, pUser, pPass, filterPolicy);
      tunnelServer = tunnel.server;
      tunnelPort = tunnel.port;
      localProxyArg = `--proxy-server=http://127.0.0.1:${tunnel.port}`;
    } catch (err) {
      if (pHost && bc.abortIfProxyFails !== false) {
        return { success: false, msg: 'A detecção de proxy falhou. O perfil não foi aberto para evitar vazamento do seu IP residencial (Política DICloak).' };
      }
    }

    // 3. Diretório local de perfil isolado para este operador
    const isEphemeral = (bc.preventDiskWrite === true);
    const userDataDir = isEphemeral
      ? path.join(os.tmpdir(), `omnicloak_ephemeral_${profile.id}_${Date.now()}`)
      : path.join(os.homedir(), '.omnicloak_profiles', `profile_${profile.id}`);

    // 3.0 Encerra preventivamente qualquer processo do Chrome preso a este perfil e remove travas Singleton
    killChromeProcessesForProfile(profile.id, userDataDir);
    await new Promise(r => setTimeout(r, 200));

    const defaultDir = path.join(userDataDir, 'Default');
    if (!fs.existsSync(defaultDir)) fs.mkdirSync(defaultDir, { recursive: true });
    // Força desativação total e remoção da barra de favoritos do Chrome
    try {
      const prefFile = path.join(defaultDir, 'Preferences');
      let prefs = {};
      if (fs.existsSync(prefFile)) {
        try { prefs = JSON.parse(fs.readFileSync(prefFile, 'utf8')); } catch(e) {}
      }
      // Barra de favoritos nativa com atalho automático para a página inicial
      if (!prefs.bookmark_bar) prefs.bookmark_bar = {};
      prefs.bookmark_bar.show_on_all_tabs = true;
      prefs.bookmark_bar.show_apps_shortcut = false;
      if (!prefs.browser) prefs.browser = {};
      prefs.browser.check_default_browser = false;
      prefs.browser.has_seen_welcome_page = true;
      if (!prefs.sync_promo) prefs.sync_promo = {};
      prefs.sync_promo.show_on_first_run_allowed = false;
      fs.writeFileSync(prefFile, JSON.stringify(prefs, null, 2), 'utf8');

      const bookmarksFile = path.join(defaultDir, 'Bookmarks');
      const startUrl = (liveProfile.urls && liveProfile.urls[0]) || 'https://v3.quantdata.us';
      const cleanProfileName = (profile.name || '').trim();
      const bookmarkLabel = cleanProfileName ? `⭐ Início (${cleanProfileName})` : '⭐ Início';
      let bData = {
        checksum: "",
        roots: {
          bookmark_bar: {
            children: [],
            date_added: "13300000000000000",
            date_modified: "13300000000000000",
            id: "1",
            name: "Barra de favoritos",
            type: "folder"
          },
          other: { children: [], id: "2", name: "Outros favoritos", type: "folder" },
          synced: { children: [], id: "3", name: "Favoritos móveis", type: "folder" }
        },
        version: 1
      };
      if (fs.existsSync(bookmarksFile)) {
        try {
          const parsed = JSON.parse(fs.readFileSync(bookmarksFile, 'utf8'));
          if (parsed && parsed.roots && parsed.roots.bookmark_bar) {
            bData = parsed;
          }
        } catch(e) {}
      }
      // EXATAMENTE 1 FAVORITO LIMPO (★ Início) - Elimina duplicatas acumuladas
      bData.roots.bookmark_bar.children = [{
        date_added: "13300000000000000",
        date_last_used: "0",
        id: "100",
        name: bookmarkLabel,
        type: "url",
        url: startUrl
      }];
      fs.writeFileSync(bookmarksFile, JSON.stringify(bData, null, 2), 'utf8');
    } catch(e) {}

    // Limpeza de cache local antes de abrir (Política DICloak)
    if (ds.cleanLocalCache && ds.cleanLocalCache.frequency === 'on_open') {
      const items = ds.cleanLocalCache.items || {};
      try {
        if (items.cookies) {
          const cookiePath = path.join(defaultDir, 'Network', 'Cookies');
          if (fs.existsSync(cookiePath)) fs.unlinkSync(cookiePath);
        }
        if (items.localStorage) {
          const lsPath = path.join(defaultDir, 'Local Storage');
          if (fs.existsSync(lsPath)) fs.rmSync(lsPath, { recursive: true, force: true });
        }
        if (items.cache) {
          const cachePath = path.join(defaultDir, 'Cache');
          if (fs.existsSync(cachePath)) fs.rmSync(cachePath, { recursive: true, force: true });
        }
      } catch (e) {}
    }

    // === 3.1 SINAL EXPLÍCITO DE LIMPEZA DA NUVEM (forceClear) ===
    const __serverClearedAt = liveProfile.sessionClearedAt || null;
    const __clearStateFile = path.join(app.getPath('userData'), 'omniClearState.json');
    let __clearState = {};
    try { if (fs.existsSync(__clearStateFile)) __clearState = JSON.parse(fs.readFileSync(__clearStateFile, 'utf8')) || {}; } catch(e) { __clearState = {}; }
    const __localClearedAt = __clearState[profile.id] || null;
    const isForceClear = Boolean(__serverClearedAt) && (__serverClearedAt !== __localClearedAt);

    if (isForceClear) {
      console.log(`[OmniCloak] SINAL FORÇADO DE LIMPEZA DA NUVEM (forceClear=true) para ${profile.name}. Purgando cookies e sessões locais do disco.`);
      const forcePurgeItems = [
        path.join('Network', 'Cookies'),
        path.join('Network', 'Cookies-journal'),
        'Cookies',
        'Cookies-journal',
        'cookies.json',
        'Local Storage',
        'Session Storage',
        'IndexedDB',
        'Sessions',
        'blob_storage'
      ];
      for (const item of forcePurgeItems) {
        const itemPath = path.join(defaultDir, item);
        if (fs.existsSync(itemPath)) {
          try { fs.rmSync(itemPath, { recursive: true, force: true }); } catch(e) {}
        }
      }
    }

    // 4. Download da Sessão Master Concorrente da Nuvem
    let sessionCookies = [];
    let cloudHadSession = false;

    if (!isForceClear) {
      try {
        const sessResp = await requestJson(`${currentServerUrl}/api/profiles/${profile.id}/session`);
        if (sessResp && sessResp.code === 0 && sessResp.data) {
          if (sessResp.data.cookies) {
            sessResp.data.cookies = decryptCookiesIfNeeded(sessResp.data.cookies);
          }
        }
        if (sessResp && sessResp.code === 0 && sessResp.data && (sessResp.data.hasSession || sessResp.data.hasArchive || (Array.isArray(sessResp.data.cookies) && sessResp.data.cookies.length > 0))) {
          cloudHadSession = true;
          // Substituicao limpa: remove SQLite e cookies antigos no disco para que os novos tenham precedencia absoluta
          const oldCookiePaths = [
            path.join(defaultDir, 'Cookies'),
            path.join(defaultDir, 'Cookies-journal'),
            path.join(defaultDir, 'Network', 'Cookies'),
            path.join(defaultDir, 'Network', 'Cookies-journal'),
            path.join(defaultDir, 'cookies.json')
          ];
          for (const cp of oldCookiePaths) {
            if (fs.existsSync(cp)) {
              try { fs.unlinkSync(cp); } catch(e) {}
            }
          }
          if (sessResp.data.sessionBase64) {
            const tempTarPath = path.join(os.tmpdir(), `session_${profile.id}_${Date.now()}.tar.gz`);
            fs.writeFileSync(tempTarPath, Buffer.from(sessResp.data.sessionBase64, 'base64'));
            const isWin = process.platform === 'win32';
            const tarCmd = isWin ? 'tar.exe' : 'tar';
            try {
              const { spawnSync } = require('child_process');
              spawnSync(tarCmd, ['-xzf', tempTarPath, '-C', defaultDir]);
            } catch (e) {
              console.error('[OmniCloak] Erro ao descompactar tar da sessão:', e);
            }
            try { fs.unlinkSync(tempTarPath); } catch (e) {}
          }
          if (Array.isArray(sessResp.data.cookies) && sessResp.data.cookies.length > 0) {
            sessionCookies = sessResp.data.cookies;
          }
        }
      } catch (e) {
        console.error('[OmniCloak] Falha ao baixar sessão da nuvem:', e.message);
      }

      // Carrega cookies extraidos do tar ou backup do perfil
      const extractedCookiesFile = path.join(defaultDir, 'cookies.json');
      if (!sessionCookies.length && fs.existsSync(extractedCookiesFile)) {
        try {
          const parsed = JSON.parse(fs.readFileSync(extractedCookiesFile, 'utf8'));
          if (Array.isArray(parsed) && parsed.length > 0) sessionCookies = parsed;
        } catch(e) {}
      }

      if (!sessionCookies.length) {
        if (Array.isArray(liveProfile.masterCookiesBackup) && liveProfile.masterCookiesBackup.length > 0) {
          sessionCookies = liveProfile.masterCookiesBackup;
        } else if (Array.isArray(liveProfile.cookies) && liveProfile.cookies.length > 0) {
          sessionCookies = liveProfile.cookies;
        }
      }
    } else {
      sessionCookies = [];
      console.log(`[OmniCloak] forceClear=true ativo. Sessão e cookies zerados incondicionalmente.`);
    }

    // Se a nuvem estiver realmente vazia (sem sessao nem cookies em lugar nenhum), garante limpeza local
    const cloudHasProfileCookies = Boolean(
      (Array.isArray(liveProfile.cookies) && liveProfile.cookies.length > 0) ||
      (Array.isArray(liveProfile.masterCookiesBackup) && liveProfile.masterCookiesBackup.length > 0) ||
      sessionCookies.length > 0
    );
    if (!cloudHadSession && !cloudHasProfileCookies) {
      console.log(`[OmniCloak] Nuvem sem sessao para ${profile.name}. Limpando dados locais.`);
      try {
        const toPurge = ['cookies.json', 'Network', 'Cookies', 'Local Storage', 'IndexedDB', 'Sessions', 'Session Storage', 'blob_storage'];
        for (const item of toPurge) {
          const itemPath = path.join(defaultDir, item);
          if (fs.existsSync(itemPath)) {
            try { fs.rmSync(itemPath, { recursive: true, force: true }); } catch(e) {}
          }
        }
      } catch(e) {}
    }

    // 5. Configuração de Fingerprint & Camuflagens Anti-Detect
    let fp = Object.assign({}, liveProfile.fingerprint || liveProfile.config || {});
    if (bc.randomFpOnStart === true) {
      const prefixes = ['PC', 'DESKTOP', 'WORKSTATION', 'LAPTOP'];
      const p = prefixes[Math.floor(Math.random() * prefixes.length)];
      const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      let rand = '';
      for (let i = 0; i < 11; i++) rand += chars[Math.floor(Math.random() * chars.length)];
      fp.deviceName = `${p}-${rand}`;

      const hex = '0123456789ABCDEF';
      let mac = [];
      for (let i = 0; i < 6; i++) {
        mac.push(hex[Math.floor(Math.random() * 16)] + hex[Math.floor(Math.random() * 16)]);
      }
      fp.macAddress = mac.join('-');

      const coresList = [4, 6, 8, 12, 16];
      const memList = [4, 8, 16, 32];
      const resList = ['1920x1080', '2560x1440', '1440x900', '1366x768'];
      fp.hardwareConcurrency = coresList[Math.floor(Math.random() * coresList.length)];
      fp.deviceMemory = memList[Math.floor(Math.random() * memList.length)];
      fp.screenResolution = resList[Math.floor(Math.random() * resList.length)];
      fp.canvasNoise = true;
      fp.audioNoise = true;
      fp.canvasSeed = Math.floor(Math.random() * 1000000) + 1;
      fp.webglSeed = Math.floor(Math.random() * 1000000) + 1;
      console.log('[OmniCloak randomFpOnStart] Novo fingerprint efêmero gerado:', {
        deviceName: fp.deviceName,
        macAddress: fp.macAddress,
        cores: fp.hardwareConcurrency,
        memory: fp.deviceMemory,
        res: fp.screenResolution,
        canvasSeed: fp.canvasSeed
      });
    }

    // Geo do proxy: tenta PELO TUNEL LOCAL (confiavel), depois direto no proxy, e fallback p/ IP direto.
    const realGeo = (await resolveGeoViaTunnel(tunnelPort)) || (await resolveProxyGeo(pHost, pPort, pUser, pPass)) || (await resolveDirectGeo());

    // Verificação de Região / País (abortIfRegionChanged)
    const expectedCountry = String(
      liveProfile.country ||
      liveProfile.countryCode ||
      (liveProfile.geo && (liveProfile.geo.country || liveProfile.geo.countryCode)) ||
      (proxy && (proxy.country || proxy.countryCode)) ||
      fp.country ||
      fp.countryCode ||
      (fp.geo && (fp.geo.country || fp.geo.countryCode)) ||
      ''
    ).trim().toUpperCase();

    if (bc.abortIfRegionChanged === true && expectedCountry) {
      const currentCountry = String((realGeo && (realGeo.countryCode || realGeo.country)) || '').trim().toUpperCase();
      if (currentCountry && currentCountry !== expectedCountry && !expectedCountry.includes(currentCountry) && !currentCountry.includes(expectedCountry)) {
        console.warn(`[OmniCloak abortIfRegionChanged] Região do proxy divergente da esperada (${currentCountry} ≠ ${expectedCountry}). Launch cancelado.`);
        if (tunnelServer) tunnelServer.close();
        return {
          success: false,
          msg: 'Região do proxy divergente da esperada. Launch cancelado.'
        };
      }
    }
    const tzIsValue = typeof fp.tz === 'string' && fp.tz.indexOf('/') !== -1;
    const langIsValue = typeof fp.lang === 'string' && fp.lang.indexOf('-') !== -1;
    const langByCC = { US: 'en-US', GB: 'en-GB', CA: 'en-CA', AU: 'en-AU', BR: 'pt-BR', PT: 'pt-PT', ES: 'es-ES', MX: 'es-MX', AR: 'es-AR', FR: 'fr-FR', DE: 'de-DE', IT: 'it-IT', NL: 'nl-NL', JP: 'ja-JP' };
    const localeTag = langIsValue ? fp.lang : ((realGeo && langByCC[realGeo.countryCode]) || 'en-US');
    const baseLang = localeTag.split('-')[0];
    const defaultSysTz = (typeof Intl !== 'undefined' && Intl.DateTimeFormat().resolvedOptions().timeZone) || 'America/Sao_Paulo';
    const tzValue = tzIsValue ? fp.tz : ((realGeo && realGeo.timezone) || defaultSysTz);
    function buildRealisticAcceptLanguage(loc) {
      if (!loc || loc.toLowerCase() === 'en-us' || loc.toLowerCase() === 'en') {
        return 'en-US,en;q=0.9';
      }
      const b = loc.split('-')[0];
      if (b !== loc) {
        return `${loc},${b};q=0.9,en-US;q=0.8,en;q=0.7`;
      }
      return `${loc};q=0.9,en-US;q=0.8,en;q=0.7`;
    }

    const proxyGeo = {
      timezone: tzValue,
      locale: localeTag,
      acceptLang: buildRealisticAcceptLanguage(localeTag),
      lat: (realGeo && typeof realGeo.lat === 'number') ? realGeo.lat : (tzValue.includes('Sao_Paulo') ? -23.5505 : 39.0469),
      lon: (realGeo && typeof realGeo.lon === 'number') ? realGeo.lon : (tzValue.includes('Sao_Paulo') ? -46.6333 : -77.4903),
      accuracy: 100
    };

    const cleanName = (profile.name || '').trim().toUpperCase().replace(/^#\d+\s*/, '');
    const browserTag = pc.browserTag && pc.browserTag.enabled !== false
      ? cleanName
      : '';
    const tagRule = (pc.browserTag && pc.browserTag.displayRule) || 'prefix';

    // 6. Montagem dos argumentos nativos do Chrome
    const chromePath = getChromeExecutable();
    const installedChromeVer = getInstalledChromeVersion(chromePath);
    if (installedChromeVer && fp.ua) {
      fp.ua = fp.ua.replace(/Chrome\/\d+\.\d+\.\d+\.\d+/, 'Chrome/' + installedChromeVer);
    }
    const debugPort = 9222 + (profile.serialNum % 1000);
    const startUrl = (liveProfile.urls && liveProfile.urls[0]) || 'https://v3.quantdata.us';

    const isRealRes = fp.screenResolutionMode === 'real' || fp.screenResolution === 'real';

    const finalArgs = [
      `--user-data-dir=${userDataDir}`,
      `--remote-debugging-port=${debugPort}`,
      '--remote-allow-origins=*',
      '--enable-unsafe-extension-debugging', // necessario p/ Extensions.loadUnpacked (Chrome 137+)
      `--lang=${proxyGeo.locale}`,
      '--disable-session-crashed-bubble',
      '--hide-crash-restore-bubble',
      '--no-recovery-component',
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-infobars',
      '--disable-component-update',
      '--disable-sync',
      '--disable-domain-reliability',
      '--disable-background-timer-throttling',
      '--disable-backgrounding-occluded-windows',
      '--disable-renderer-backgrounding',
      '--disable-breakpad',
      '--disable-crash-reporter',
      '--disable-ipc-flooding-protection',
      '--memory-pressure-off',
      '--disable-features=OptimizationGuideModelDownloading,OptimizationHints,ChromeWhatsNewUI,InProductHelp,UserBypassUI,PromoRegistry,PromoNotification,NotificationScheduleService,DefaultBrowserPrompt,Win10DeprecationWarning',
      '--simulate-outdated-no-au=\'Tue, 31 Dec 2099 23:59:59 GMT\'',
      '--check-for-update-interval=31536000',
      '--enable-bookmark-bar'
    ];

    // Abre sempre ocupando 100% da tela (maximizado e sem sobrar fora da janela)
    finalArgs.push('--start-maximized');
    finalArgs.push('--window-position=0,0');
    if (bc.restorePagesOnOpen !== true) {
      finalArgs.push('--no-restore-session');
      finalArgs.push('--restore-last-session=false');
    }

    if (fp.ua) finalArgs.push(`--user-agent=${fp.ua}`);

    // Bloqueia 100% vazamento de IP real do WebRTC no nivel C++ do Chromium
    finalArgs.push('--webrtc-ip-handling-policy=disable_non_proxied_udp');
    finalArgs.push('--force-webrtc-ip-handling-policy=disable_non_proxied_udp');

    if (localProxyArg) finalArgs.push(localProxyArg);

    // DevTools blocked via CDP closeTarget guardian to preserve CDP emulation functionality

    if (bc.disablePasswordBubble !== false) {
      finalArgs.push('--disable-save-password-bubble');
      finalArgs.push('--password-store=basic');
    }
    if (bc.disableImages === true) finalArgs.push('--blink-settings=imagesEnabled=false');
    if (bc.disableVideos === true) finalArgs.push('--blink-settings=mediaEnabled=false');
    if (bc.disableAudio === true) finalArgs.push('--mute-audio');
    if (bc.disableNotifications !== false) finalArgs.push('--disable-notifications');
    if (bc.disableIncognito !== false) finalArgs.push('--disable-incognito');
    if (bc.ignoreCertErrors === true) finalArgs.push('--ignore-certificate-errors');

    // Desativa o aviso cinza de "Insecure Connection / HTTPS-First" ao digitar URLs HTTP puras
    finalArgs.push('--disable-features=HttpsFirstModeV2,HttpsUpgrades');

    // Injeção de extensões associadas a este Perfil no painel de Extensões
    let loadedExtDirs = [];
    try {
      const pName = String((liveProfile && liveProfile.name) || profile.name || '').trim();
      const pId = String((liveProfile && liveProfile.id) || profile.id || '').trim();
      const targets = [pName, pId].filter(Boolean);
      loadedExtDirs = await syncProfileExtensions(targets, currentServerUrl, API_KEY);
      omniLog(`[OmniCloak Extensions] Extensões vinculadas ao perfil "${pName}": ${loadedExtDirs.length}`);
    } catch (extErr) {
      console.error('[OmniCloak Extensions Error]', extErr.message);
    }

    // Injeção de extensões descompactadas é 100% gerenciada via CDP Extensions.loadUnpacked
    // para total compatibilidade com Chrome moderno (sem flags de CLI que geram bloqueios ou alertas)

    // Pré-fixa as extensões na barra do navegador (pinned_extensions) para visibilidade imediata
    if (loadedExtDirs && loadedExtDirs.length > 0) {
      const pinnedIds = [];
      for (const ed of loadedExtDirs) {
        const idFile = path.join(ed, '.chrome_id');
        if (fs.existsSync(idFile)) {
          try {
            const sid = fs.readFileSync(idFile, 'utf8').trim();
            if (sid) pinnedIds.push(sid);
          } catch(e) {}
        }
        const eid = getUnpackedExtensionId(ed);
        if (eid) pinnedIds.push(eid);
      }
      if (pinnedIds.length > 0) {
        try {
          const defDir = path.join(userDataDir, 'Default');
          if (!fs.existsSync(defDir)) fs.mkdirSync(defDir, { recursive: true });
          const prefFile = path.join(defDir, 'Preferences');
          let prefData = {};
          if (fs.existsSync(prefFile)) {
            try { prefData = JSON.parse(fs.readFileSync(prefFile, 'utf8')); } catch(e) {}
          }
          if (!prefData.extensions) prefData.extensions = {};
          prefData.extensions.pinned_extensions = Array.from(new Set([
            ...(Array.isArray(prefData.extensions.pinned_extensions) ? prefData.extensions.pinned_extensions : []),
            ...pinnedIds
          ]));
          fs.writeFileSync(prefFile, JSON.stringify(prefData, null, 2));
        } catch(e) {
          console.warn('[OmniCloak] Falha ao gravar pinned_extensions:', e.message);
        }
      }
    }

    // Normaliza Preferences e sessão conforme política da equipe
    try {
      const defDir = path.join(userDataDir, 'Default');
      if (!fs.existsSync(defDir)) fs.mkdirSync(defDir, { recursive: true });

      // Se não for para restaurar páginas anteriores, limpa sessões antigas que causam popup de restore
      if (bc.restorePagesOnOpen !== true) {
        const oldSessionDirs = [
          path.join(defDir, 'Sessions'),
          path.join(defDir, 'Sessions_Encrypted'),
          path.join(defDir, 'Session Storage')
        ];
        for (const sDir of oldSessionDirs) {
          if (fs.existsSync(sDir)) {
            try { fs.rmSync(sDir, { recursive: true, force: true }); } catch(e) {}
          }
        }
        const oldSessionFiles = [
          'Current Session', 'Current Tabs', 'Last Session', 'Last Tabs',
          'Current Session-journal', 'Current Tabs-journal', 'Last Session-journal', 'Last Tabs-journal'
        ];
        for (const sFile of oldSessionFiles) {
          const filePath = path.join(defDir, sFile);
          if (fs.existsSync(filePath)) {
            try { fs.unlinkSync(filePath); } catch(e) {}
          }
        }
      }

      // Normaliza Preferences e Secure Preferences (Força 100% Maximizado e previne pop-up de crash/restore)
      const prefFiles = [path.join(defDir, 'Preferences'), path.join(defDir, 'Secure Preferences')];
      for (const pf of prefFiles) {
        try {
          let pData = {};
          if (fs.existsSync(pf)) {
            try { pData = JSON.parse(fs.readFileSync(pf, 'utf8')); } catch(e) { pData = {}; }
          }
          if (!pData.profile) pData.profile = {};
          pData.profile.exit_type = 'Normal';
          pData.profile.exited_cleanly = true;
          if (!pData.session) pData.session = {};
          if (bc.restorePagesOnOpen === true) {
            pData.session.restore_on_startup = 1; // Restaura as abas da sessão anterior
          } else {
            pData.session.restore_on_startup = 4; // Abre exclusivamente a startUrl
            pData.session.startup_urls = (bc.hideVerificationPage === false) ? ['https://iphey.com', startUrl] : [startUrl];
          }
          if (!pData.browser) pData.browser = {};
          if (!pData.browser.window_placement) pData.browser.window_placement = {};
          pData.browser.window_placement.maximized = true;
          pData.browser.window_placement.top = 0;
          pData.browser.window_placement.left = 0;
          fs.writeFileSync(pf, JSON.stringify(pData, null, 2), 'utf8');
        } catch(e) {}
      }

      const localStateFile = path.join(userDataDir, 'Local State');
      if (fs.existsSync(localStateFile)) {
        let ls = {};
        try { ls = JSON.parse(fs.readFileSync(localStateFile, 'utf8')); } catch(e) {}
        if (!ls.profile) ls.profile = {};
        ls.profile.exit_type = 'Normal';
        ls.profile.exited_cleanly = true;
        if (!ls.user_experience_metrics) ls.user_experience_metrics = {};
        ls.user_experience_metrics.reporting_enabled = false;
        ls.user_experience_metrics.clean_exit = true;
        if (!ls.browser) ls.browser = {};
        if (!ls.browser.window_placement) ls.browser.window_placement = {};
        ls.browser.window_placement.maximized = true;
        ls.browser.window_placement.top = 0;
        ls.browser.window_placement.left = 0;
        fs.writeFileSync(localStateFile, JSON.stringify(ls, null, 2), 'utf8');
      }
    } catch(e) {}

    // 7. Injeção de Proteção Nativa OmniShield e Extensões
    const effectiveBlockedList = [
      ...(Array.isArray(liveProfile.security && liveProfile.security.blockedUrls) ? liveProfile.security.blockedUrls : []),
      ...(Array.isArray(teamData && teamData.browserPolicy && teamData.browserPolicy.blockedUrls) ? teamData.browserPolicy.blockedUrls : [])
    ].map(s => String(s || '').trim()).filter(Boolean);

    fp.profileId = profile.id;
    const stealthCode = generateStealthScript(fp, proxyGeo, browserTag, tagRule, effectiveBlockedList, bc);

    // Cria extensão interna OmniShield que roda com prioridade máxima (document_start)
    const omniShieldDir = path.join(userDataDir, 'OmniShield');
    if (!fs.existsSync(omniShieldDir)) fs.mkdirSync(omniShieldDir, { recursive: true });
    fs.writeFileSync(path.join(omniShieldDir, 'manifest.json'), JSON.stringify({
      manifest_version: 3,
      name: "OmniCloak Shield",
      version: "1.0.0",
      content_scripts: [
        {
          matches: ["<all_urls>"],
          js: ["shield.js"],
          run_at: "document_start",
          world: "MAIN",
          all_frames: true
        }
      ]
    }, null, 2));
    fs.writeFileSync(path.join(omniShieldDir, 'shield.js'), stealthCode);

    // Injeção de extensões corporativas é realizada 100% via CDP Extensions.loadUnpacked
    // Flags --load-extension e --disable-extensions-except removidas para compatibilidade com Chrome 137+
    for (const a of chromeArgs) {
      if (a.startsWith('--load-extension') || a.startsWith('--disable-extensions-except') || a.startsWith('--user-data-dir') || a.startsWith('--proxy-server') || a.includes('--disable-blink-features=AutomationControlled') || a.startsWith('--remote-debugging-port') || a.startsWith('--user-agent') || a.startsWith('--window-size')) continue;
      finalArgs.push(a);
    }

    const initialPages = [];
    if (bc.hideVerificationPage === false) {
      initialPages.push('https://iphey.com');
    }
    if (startUrl && !initialPages.includes(startUrl)) {
      initialPages.push(startUrl);
    }
    if (initialPages.length === 0) {
      initialPages.push('https://v3.quantdata.us');
    }
    finalArgs.push('--disable-dev-tools');
    finalArgs.push('about:blank');

    // Origens para limpeza profunda de Storage (LocalStorage, IndexedDB, JWTs)
    const originsToClear = new Set();
    if (startUrl) {
      try { originsToClear.add(new URL(startUrl).origin); } catch(e) {}
    }
    if (Array.isArray(liveProfile.urls)) {
      for (const u of liveProfile.urls) {
        try { originsToClear.add(new URL(u).origin); } catch(e) {}
      }
    }
    originsToClear.add('https://v3.quantdata.us');
    originsToClear.add('https://dashboard.spotgamma.com');
    originsToClear.add('https://menthorq.com');
    originsToClear.add('https://www.financialjuice.com');
    originsToClear.add('https://financialjuice.com');

    // 8. Spawn Chrome com Fuso Horário e Políticas da Equipe
    applyChromeEnterprisePolicies(liveProfile, globalSettings, teamData);

    // Envia ACK ao servidor se forceClear foi consumido com sucesso
    if (isForceClear) {
      try {
        try { __clearState[profile.id] = __serverClearedAt; fs.writeFileSync(__clearStateFile, JSON.stringify(__clearState), 'utf8'); console.log('[OmniCloak] Limpeza aplicada e registrada localmente (sessionClearedAt=' + __serverClearedAt + ') para ' + profile.name); } catch(e) {}
      } catch(e) {}
    }
    const chromeProc = spawn(chromePath, finalArgs, {
      detached: false,
      stdio: 'ignore',
      env: Object.assign({}, process.env, proxyGeo.timezone ? { TZ: proxyGeo.timezone } : {})
    });
    (async () => {
      let cdpWs = null; let __omniInitialNavDone = false;
      let browserVer = '';
      for (let i = 0; i < 40; i++) {
        await new Promise(r => setTimeout(r, 200));
        try {
          const ver = await requestJson(`http://127.0.0.1:${debugPort}/json/version`);
          browserVer = (ver && ver.Browser) || browserVer;
          if (ver && ver.webSocketDebuggerUrl) {
            cdpWs = new WebSocket(ver.webSocketDebuggerUrl);
            activeCdpWs = cdpWs;
            break;
          }
        } catch (e) {}
      }

      if (cdpWs) {
        let initialCookiesInjected = false;
        const targetSessionMap = new Map();
        let initialPageTargetId = null;

        const configureSession = (sid, isInitial = false) => {
          // 1. Fuso Horário Nativo V8
          if (proxyGeo.timezone) {
            cdpWs.send(JSON.stringify({
              sessionId: sid,
              id: 203,
              method: 'Emulation.setTimezoneOverride',
              params: { timezoneId: proxyGeo.timezone }
            }));
          }

          // 2. Geolocalização Nativa
          if (proxyGeo.lat != null && proxyGeo.lon != null) {
            cdpWs.send(JSON.stringify({
              sessionId: sid,
              id: 204,
              method: 'Emulation.setGeolocationOverride',
              params: { latitude: proxyGeo.lat, longitude: proxyGeo.lon, accuracy: 100 }
            }));
          }

          // 3. User-Agent e Idioma Nativos
          // 3. User-Agent + Client Hints alinhados a VERSAO REAL do motor Chromium
          {
            const __rf = ((browserVer || '').match(/Chrome\/(\d+\.\d+\.\d+\.\d+)/) || [])[1] || installedChromeVer || null;
            const __rmaj = __rf ? __rf.split('.')[0] : null;
            const __mac = !!(fp.ua && fp.ua.includes('Macintosh'));
            let __ua = fp.ua || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.8078.48 Safari/537.36';
            if (__rf) __ua = __ua.replace(/Chrome\/\d+\.\d+\.\d+\.\d+/, 'Chrome/' + __rf);
            const __params = {
              userAgent: __ua,
              acceptLanguage: proxyGeo.acceptLang.replace(/;q=[0-9.]+/g, ''),
              platform: __mac ? 'MacIntel' : 'Win32'
            };
            if (__rf && __rmaj) {
              __params.userAgentMetadata = {
                brands: [ { brand: 'Not:A-Brand', version: '8' }, { brand: 'Chromium', version: __rmaj }, { brand: 'Google Chrome', version: __rmaj } ],
                fullVersion: __rf,
                fullVersionList: [ { brand: 'Not:A-Brand', version: '8.0.0.0' }, { brand: 'Chromium', version: __rf }, { brand: 'Google Chrome', version: __rf } ],
                platform: __mac ? 'macOS' : 'Windows',
                platformVersion: __mac ? '13.0.0' : '10.0.0',
                architecture: __mac ? 'arm' : 'x86',
                bitness: '64', model: '', mobile: false, wow64: false
              };
            }
            cdpWs.send(JSON.stringify({ sessionId: sid, id: 205, method: 'Emulation.setUserAgentOverride', params: __params }));
          }

          // 4. Injeção de Stealth
          cdpWs.send(JSON.stringify({
            sessionId: sid,
            id: 2069,
            method: 'Page.enable'
          }));
          cdpWs.send(JSON.stringify({
            sessionId: sid,
            id: 207,
            method: 'Page.addScriptToEvaluateOnNewDocument',
            params: { source: stealthCode }
          }));

          // 4.1 Injeta e executa imediatamente no documento atual (sem esperar reload)
          cdpWs.send(JSON.stringify({
            sessionId: sid,
            id: 2071,
            method: 'Runtime.evaluate',
            params: { expression: stealthCode }
          }));

          // Se forceClear estiver ativo, limpa TODO o storage (cookies, LocalStorage, IndexedDB, cache) via CDP
          if (isInitial && isForceClear) {
            console.log('[OmniCloak CDP] forceClear ativo: limpando TODO storage (cookies, localStorage, indexedDB, tokens) via CDP');
            cdpWs.send(JSON.stringify({
              sessionId: sid,
              id: 299,
              method: 'Network.clearBrowserCookies'
            }));
            cdpWs.send(JSON.stringify({
              sessionId: sid,
              id: 300,
              method: 'Storage.clearCookies'
            }));
            for (const orig of originsToClear) {
              cdpWs.send(JSON.stringify({
                sessionId: sid,
                id: 301,
                method: 'Storage.clearDataForOrigin',
                params: {
                  origin: orig,
                  storageTypes: 'all'
                }
              }));
            }
            const domClearScript = `
              try { localStorage.clear(); } catch(e) {}
              try { sessionStorage.clear(); } catch(e) {}
              try {
                if (window.indexedDB && window.indexedDB.databases) {
                  window.indexedDB.databases().then(function(dbs) {
                    if (Array.isArray(dbs)) {
                      dbs.forEach(function(db) { if (db && db.name) window.indexedDB.deleteDatabase(db.name); });
                    }
                  }).catch(function(){});
                }
              } catch(e) {}
            `;
            cdpWs.send(JSON.stringify({
              sessionId: sid,
              id: 302,
              method: 'Runtime.evaluate',
              params: { expression: domClearScript }
            }));
          }

          // 5. Injeta Cookies Master
          if (isInitial && !initialCookiesInjected && Array.isArray(sessionCookies) && sessionCookies.length > 0) {
            initialCookiesInjected = true;
            // Limpa cookies residuais no browser antes de injetar os novos master
            cdpWs.send(JSON.stringify({
              sessionId: sid,
              id: 299,
              method: 'Network.clearBrowserCookies'
            }));
            let fallbackHost = 'menthorq.com';
            try { fallbackHost = new URL(startUrl).hostname; } catch(e) {}
            const cleanCookies = sessionCookies.map(c => {
              const domainClean = c.domain ? c.domain.replace(/^\./, '') : fallbackHost;
              const isSecure = c.secure === true;
              const protocol = isSecure ? 'https://' : 'http://';
              return {
                name: String(c.name),
                value: String(c.value),
                url: `${protocol}${domainClean}${c.path || '/'}`,
                domain: c.domain,
                path: c.path || '/',
                secure: isSecure,
                httpOnly: c.httpOnly === true,
                ...(c.expires && c.expires > 0 ? { expires: c.expires } : {}),
                ...(c.sameSite && ['Strict', 'Lax', 'None'].includes(c.sameSite) ? { sameSite: c.sameSite } : {})
              };
            });
            cdpWs.send(JSON.stringify({
              sessionId: sid,
              id: 301,
              method: 'Network.setCookies',
              params: { cookies: cleanCookies }
            }));
          }

          // 6. Libera execução se estiver aguardando depurador
          cdpWs.send(JSON.stringify({
            sessionId: sid,
            id: 208,
            method: 'Runtime.runIfWaitingForDebugger'
          }));

          if (isInitial) {
            const firstTargetUrl = (initialPages && initialPages[0]) || startUrl || 'https://v3.quantdata.us';
            const __openExtraTabs = () => {
              try {
                if (initialPages && initialPages.length > 1) {
                  for (let pIdx = 1; pIdx < initialPages.length; pIdx++) {
                    cdpWs.send(JSON.stringify({ id: 3040 + pIdx, method: 'Target.createTarget', params: { url: initialPages[pIdx] } }));
                  }
                }
              } catch(e) {}
            };
            const __doNav = () => {
              try {
                if (cdpWs && cdpWs.readyState === WebSocket.OPEN) {
                  cdpWs.send(JSON.stringify({ sessionId: sid, id: 304, method: 'Page.navigate', params: { url: firstTargetUrl } }));
                }
              } catch(e) {}
            };
            setTimeout(() => { __doNav(); __openExtraTabs(); }, 100);
            // Watchdog: enquanto a aba inicial continuar em about:blank, re-navega (CDP pode atrasar/falhar)
            let __navTries = 0;
            const __navWatch = setInterval(() => {
              __navTries++;
              if (__omniInitialNavDone || __navTries > 5 || !cdpWs || cdpWs.readyState !== WebSocket.OPEN) { clearInterval(__navWatch); return; }
              __doNav();
            }, 1200);
          }
        };

        cdpWs.on('open', () => {
          cdpWs.send(JSON.stringify({ id: 1, method: 'Target.getTargets' }));
          cdpWs.send(JSON.stringify({ id: 10, method: 'Target.setDiscoverTargets', params: { discover: true } }));
          cdpWs.send(JSON.stringify({
            id: 15,
            method: 'Target.setAutoAttach',
            params: { autoAttach: true, waitForDebuggerOnStart: true, flatten: true }
          }));

          if (isForceClear) {
            console.log('[OmniCloak CDP open] forceClear ativo: limpando cookies e TODO storage de origens via CDP');
            cdpWs.send(JSON.stringify({ id: 295, method: 'Network.clearBrowserCookies' }));
            cdpWs.send(JSON.stringify({ id: 296, method: 'Storage.clearCookies' }));
            for (const orig of originsToClear) {
              cdpWs.send(JSON.stringify({
                id: 297,
                method: 'Storage.clearDataForOrigin',
                params: {
                  origin: orig,
                  storageTypes: 'all'
                }
              }));
            }
          }

          // Injeta Cookies Master instantaneamente via CDP Storage.setCookies
          if (Array.isArray(sessionCookies) && sessionCookies.length > 0) {
            cdpWs.send(JSON.stringify({ id: 297, method: 'Network.clearBrowserCookies' }));
            cdpWs.send(JSON.stringify({ id: 298, method: 'Storage.clearCookies' }));
            let fallbackHost = 'menthorq.com';
            try { fallbackHost = new URL(startUrl).hostname; } catch(e) {}
            const cleanCookies = sessionCookies.map(c => {
              const domainClean = c.domain ? c.domain.replace(/^\./, '') : fallbackHost;
              const isSecure = c.secure === true;
              return {
                name: String(c.name),
                value: String(c.value),
                domain: c.domain || ('.' + fallbackHost),
                path: c.path || '/',
                secure: isSecure,
                httpOnly: c.httpOnly === true,
                ...(c.expires && c.expires > 0 ? { expires: c.expires } : {}),
                ...(c.sameSite && ['Strict', 'Lax', 'None'].includes(c.sameSite) ? { sameSite: c.sameSite } : {})
              };
            });
            cdpWs.send(JSON.stringify({
              id: 300,
              method: 'Storage.setCookies',
              params: { cookies: cleanCookies }
            }));
            console.log(`[OmniCloak CDP] ${cleanCookies.length} cookies master injetados via Storage.setCookies.`);
          }

          // Injeção de Cookies Master concluída. Zero polling de cookies em runtime para máxima leveza.

          // Injeta as extensões desbloqueadas via CDP Extensions.loadUnpacked nativo
          omniLog('CDP open | chrome=' + browserVer + ' | loadedExtDirs=' + JSON.stringify(loadedExtDirs));
          if (Array.isArray(loadedExtDirs) && loadedExtDirs.length > 0) {
            loadedExtDirs.forEach((extPath, idx) => {
              cdpWs.send(JSON.stringify({
                id: 8000 + idx,
                method: 'Extensions.loadUnpacked',
                params: { path: extPath }
              }));
            });
            console.log('[OmniCloak Extensions] Injetadas com sucesso via CDP Extensions.loadUnpacked:', loadedExtDirs);
          }
        });

        cdpWs.on('message', (data) => {
          try {
            const msg = JSON.parse(data.toString());
            // Captura cookies atualizados do navegador
            if (msg.id === 7001 && msg.result && Array.isArray(msg.result.cookies)) {
              latestCookies = msg.result.cookies;
            }
            if (msg.id >= 8000 && msg.id < 9000) {
              omniLog(msg.error ? ('loadUnpacked ERRO: ' + JSON.stringify(msg.error)) : ('loadUnpacked OK: ' + JSON.stringify(msg.result)));
              if (msg.result && msg.result.id) {
                const extIdx = msg.id - 8000;
                if (loadedExtDirs && loadedExtDirs[extIdx]) {
                  const idFile = path.join(loadedExtDirs[extIdx], '.chrome_id');
                  try { fs.writeFileSync(idFile, msg.result.id); } catch(e) {}
                }
              }
            }
            if (msg.method === 'Target.targetCreated' || msg.method === 'Target.targetInfoChanged') {
              const tInfo = msg.params && msg.params.targetInfo;
              if (tInfo && tInfo.url) {
                const u = tInfo.url.toLowerCase();
                if (!allowSettings && (u.startsWith('chrome://settings') || u.startsWith('chrome://flags') || u.startsWith('chrome://version'))) {
                  console.log('[OmniCloak Guardian] Fechando aba de configuracoes:', tInfo.url);
                  cdpWs.send(JSON.stringify({ id: 9991, method: 'Target.closeTarget', params: { targetId: tInfo.targetId } }));
                }
                if (!allowExtensions && (u.startsWith('chrome://extensions') || u.includes('chromewebstore.google.com') || u.includes('chrome.google.com/webstore'))) {
                  console.log('[OmniCloak Guardian] Fechando aba de extensoes:', tInfo.url);
                  cdpWs.send(JSON.stringify({ id: 9992, method: 'Target.closeTarget', params: { targetId: tInfo.targetId } }));
                }
                if ((!allowDevTools || bc.preventTampering === true) && (u.startsWith('devtools://') || (tInfo.type === 'other' && u.includes('devtools')))) {
                  console.log('[OmniCloak Guardian] Fechando DevTools:', tInfo.url);
                  cdpWs.send(JSON.stringify({ id: 9993, method: 'Target.closeTarget', params: { targetId: tInfo.targetId } }));
                }
                if ((!allowSettings || bc.preventViewingPasswords !== false) && (u.startsWith('chrome://password-manager') || u.startsWith('chrome://settings/passwords'))) {
                  console.log('[OmniCloak Guardian] Fechando gerenciador de senhas:', tInfo.url);
                  cdpWs.send(JSON.stringify({ id: 9994, method: 'Target.closeTarget', params: { targetId: tInfo.targetId } }));
                }
                if (effectiveBlockedList.length > 0 && isUrlBlocked(tInfo.url, effectiveBlockedList)) {
                  console.log('[OmniCloak Guardian] URL/Subpasta restrita detectada via CDP, bloqueando tela:', tInfo.url);
                  const evalBlockExpr = `
                    (function() {
                      try {
                        var targetStr = ${JSON.stringify(tInfo.url || '')};
                        var overlayId = 'omnicloak-block-overlay';
                        var existing = document.getElementById(overlayId);
                        if (!existing) {
                          existing = document.createElement('div');
                          existing.id = overlayId;
                          existing.style.cssText = 'position:fixed !important;top:0 !important;left:0 !important;right:0 !important;bottom:0 !important;width:100vw !important;height:100vh !important;background:#0b0f19 !important;color:#f8fafc !important;font-family:-apple-system,BlinkMacSystemFont,\\"Segoe UI\\",Roboto,sans-serif !important;display:flex !important;align-items:center !important;justify-content:center !important;z-index:2147483647 !important;margin:0 !important;padding:20px !important;box-sizing:border-box !important;overflow:auto !important;';
                          existing.innerHTML = '<div style="background:#161f30;border:2px solid #ef4444;border-radius:16px;padding:36px;text-align:center;max-width:520px;width:90%;box-shadow:0 25px 60px rgba(0,0,0,0.85);box-sizing:border-box;margin:auto;"><div style="font-size:56px;margin-bottom:14px;line-height:1;">🚫</div><h2 style="margin:0 0 10px 0;color:#ef4444;font-size:24px;font-weight:800;letter-spacing:-0.5px;">Acesso Bloqueado</h2><p style="margin:0 0 16px 0;color:#94a3b8;font-size:14px;line-height:1.5;">Esta página e suas configurações confidenciais estão bloqueadas pela política de segurança da sua equipe.</p><div style="background:#0f172a;border:1px solid #334155;color:#f87171;font-family:monospace;font-size:12px;padding:10px 14px;border-radius:6px;word-break:break-all;margin-bottom:24px;display:block;width:100%;box-sizing:border-box;text-align:left;"><strong>URL Bloqueada:</strong> <span id="omnicloak-cdp-span1"></span></div><button id="omnicloak-cdp-btn1" style="background:#2563eb;color:#ffffff;border:none;padding:13px 30px;border-radius:8px;font-weight:700;cursor:pointer;font-size:14px;transition:background 0.2s;display:inline-block;text-decoration:none;">🏠 Voltar para a Página Inicial</button></div>';
                          (document.body || document.documentElement).appendChild(existing);
                          var b = document.getElementById('omnicloak-cdp-btn1');
                          if (b) {
                            b.onclick = function(e) {
                              e.preventDefault();
                              window.location.replace(window.location.origin + '/');
                            };
                          }
                        }
                        var s = document.getElementById('omnicloak-cdp-span1');
                        if (s) s.textContent = targetStr;
                      } catch(e) {}
                    })();
                  `;
                  const targetSid = targetSessionMap.get(tInfo.targetId);
                  if (targetSid) {
                    cdpWs.send(JSON.stringify({
                      sessionId: targetSid,
                      id: 9995,
                      method: 'Runtime.evaluate',
                      params: { expression: evalBlockExpr }
                    }));
                  }
                  try {
                    cdpWs.send(JSON.stringify({
                      method: 'Target.sendMessageToTarget',
                      params: {
                        targetId: tInfo.targetId,
                        message: JSON.stringify({
                          id: 9996,
                          method: 'Runtime.evaluate',
                          params: { expression: evalBlockExpr }
                        })
                      }
                    }));
                  } catch(e) {}
                }
              }
            }
            if (msg.method === 'Page.navigatedWithinDocument' || msg.method === 'Page.frameNavigated') {
              const navUrl = (msg.params && (msg.params.url || (msg.params.frame && msg.params.frame.url))) || ''; if (navUrl && !/^about:blank/i.test(navUrl)) { __omniInitialNavDone = true; }
              if (navUrl && effectiveBlockedList.length > 0 && isUrlBlocked(navUrl, effectiveBlockedList)) {
                console.log('[OmniCloak Guardian] SPA rota bloqueada via CDP:', navUrl);
                const evalBlockExpr = `
                  (function() {
                    try {
                      var targetStr = ${JSON.stringify(navUrl || '')};
                      var overlayId = 'omnicloak-block-overlay';
                      var existing = document.getElementById(overlayId);
                      if (!existing) {
                        existing = document.createElement('div');
                        existing.id = overlayId;
                        existing.style.cssText = 'position:fixed !important;top:0 !important;left:0 !important;right:0 !important;bottom:0 !important;width:100vw !important;height:100vh !important;background:#0b0f19 !important;color:#f8fafc !important;font-family:-apple-system,BlinkMacSystemFont,\\"Segoe UI\\",Roboto,sans-serif !important;display:flex !important;align-items:center !important;justify-content:center !important;z-index:2147483647 !important;margin:0 !important;padding:20px !important;box-sizing:border-box !important;overflow:auto !important;';
                        existing.innerHTML = '<div style="background:#161f30;border:2px solid #ef4444;border-radius:16px;padding:36px;text-align:center;max-width:520px;width:90%;box-shadow:0 25px 60px rgba(0,0,0,0.85);box-sizing:border-box;margin:auto;"><div style="font-size:56px;margin-bottom:14px;line-height:1;">🚫</div><h2 style="margin:0 0 10px 0;color:#ef4444;font-size:24px;font-weight:800;letter-spacing:-0.5px;">Acesso Bloqueado</h2><p style="margin:0 0 16px 0;color:#94a3b8;font-size:14px;line-height:1.5;">Esta página e suas configurações confidenciais estão bloqueadas pela política de segurança da sua equipe.</p><div style="background:#0f172a;border:1px solid #334155;color:#f87171;font-family:monospace;font-size:12px;padding:10px 14px;border-radius:6px;word-break:break-all;margin-bottom:24px;display:block;width:100%;box-sizing:border-box;text-align:left;"><strong>URL Bloqueada:</strong> <span id="omnicloak-cdp-span2"></span></div><button id="omnicloak-cdp-btn2" style="background:#2563eb;color:#ffffff;border:none;padding:13px 30px;border-radius:8px;font-weight:700;cursor:pointer;font-size:14px;transition:background 0.2s;display:inline-block;text-decoration:none;">🏠 Voltar para a Página Inicial</button></div>';
                        (document.body || document.documentElement).appendChild(existing);
                        var b = document.getElementById('omnicloak-cdp-btn2');
                        if (b) {
                          b.onclick = function(e) {
                            e.preventDefault();
                            window.location.replace(window.location.origin + '/');
                          };
                        }
                      }
                      var s = document.getElementById('omnicloak-cdp-span2');
                      if (s) s.textContent = targetStr;
                    } catch(e) {}
                  })();
                `;
                if (msg.sessionId) {
                  cdpWs.send(JSON.stringify({
                    sessionId: msg.sessionId,
                    id: 9998,
                    method: 'Runtime.evaluate',
                    params: { expression: evalBlockExpr }
                  }));
                }
              }
            }
            if (msg.id === 50 && msg.result && msg.result.windowId) {
              cdpWs.send(JSON.stringify({
                id: 51,
                method: 'Browser.setWindowBounds',
                params: {
                  windowId: msg.result.windowId,
                  bounds: { windowState: 'maximized' }
                }
              }));
              console.log('[OmniCloak Window] Janela maximizada com sucesso via CDP.');
            }
            if (msg.method === 'Target.attachedToTarget' && msg.params && msg.params.sessionId) {
              const sid = msg.params.sessionId;
              const tInfo = msg.params.targetInfo || {};
              if (tInfo.targetId) {
                targetSessionMap.set(tInfo.targetId, sid);
                try {
                  cdpWs.send(JSON.stringify({
                    id: 50,
                    method: 'Browser.getWindowForTarget',
                    params: { targetId: tInfo.targetId }
                  }));
                } catch(e) {}
              }
              if (tInfo.type === 'page') {
                configureSession(sid, !initialCookiesInjected);
              }
            }
            if (msg.method === 'Target.detachedFromTarget' && msg.params && msg.params.targetId) {
              targetSessionMap.delete(msg.params.targetId);
            }
            if (msg.id === 1 && msg.result && Array.isArray(msg.result.targetInfos)) {
              const pageTarget = msg.result.targetInfos.find(t => t.type === 'page');
              if (pageTarget) {
                initialPageTargetId = pageTarget.targetId;
                cdpWs.send(JSON.stringify({
                  id: 2,
                  method: 'Target.attachToTarget',
                  params: { targetId: pageTarget.targetId, flatten: true }
                }));
                try {
                  cdpWs.send(JSON.stringify({
                    id: 50,
                    method: 'Browser.getWindowForTarget',
                    params: { targetId: pageTarget.targetId }
                  }));
                } catch(e) {}
              }
            }
            if (msg.id === 2 && msg.result && msg.result.sessionId) {
              const sid = msg.result.sessionId;
              if (initialPageTargetId) targetSessionMap.set(initialPageTargetId, sid);
              configureSession(sid, true);
              setTimeout(() => {
                try {
                  cdpWs.send(JSON.stringify({ sessionId: sid, id: 302, method: 'Page.reload' }));
                } catch(e) {}
              }, 120);
            }
          } catch(e) {}
        });
      }
    })();

    let heartbeatTimer = setInterval(async () => {
      try {
        const tokenParam = (currentAuth && currentAuth.appSessionToken) ? `&sessionToken=${encodeURIComponent(currentAuth.appSessionToken)}` : '';
        const check = await requestJson(`${currentServerUrl}/api/profiles/${profile.id}/heartbeat?user=${encodeURIComponent(currentAuth.username)}${tokenParam}`);
        if (check && check.data && (check.data.closeRequired === true || check.data.kicked === true)) {
          console.log(`[OmniCloak Remote Kill] Fechamento remoto solicitado para "${profile.name}".`);
          if (heartbeatTimer) clearInterval(heartbeatTimer);
          if (activeCdpWs && activeCdpWs.readyState === WebSocket.OPEN) {
            try { activeCdpWs.send(JSON.stringify({ id: 9999, method: 'Browser.close' })); } catch(e) {}
          }
          setTimeout(() => {
            try { chromeProc.kill(); } catch(e) {}
          }, 600);
        }
      } catch(e) {}
    }, 5 * 60 * 1000); // 5 minutos (super leve)

    const sessionInfo = {
      proc: chromeProc,
      tunnelServer,
      profileId: profile.id,
      serialNum: profile.serialNum,
      userDataDir,
      heartbeatTimer,
      get cdpWs() { return activeCdpWs; }
    };
    activeSessions.set(profile.serialNum, sessionInfo);

    chromeProc.on('exit', async () => {
      if (heartbeatTimer) clearInterval(heartbeatTimer);
      try {
        await requestJson(`${currentServerUrl}/api/profiles/${profile.id}/stop?user=${encodeURIComponent(currentAuth.username)}`, { method: 'POST' });
      } catch(e) {}
      if (tunnelServer) tunnelServer.close();
      if (activeCdpWs) {
        try { activeCdpWs.terminate(); } catch(e) {}
      }
      activeSessions.delete(profile.serialNum);

      if (isEphemeral) {
        console.log(`[OmniCloak preventDiskWrite] Perfil efêmero finalizado. Descartando gravação em disco e pulando sync de sessão.`);
        try {
          if (fs.existsSync(userDataDir)) {
            fs.rmSync(userDataDir, { recursive: true, force: true });
            console.log(`[OmniCloak preventDiskWrite] Diretório temporário removido com sucesso: ${userDataDir}`);
          }
        } catch(rmErr) {
          console.warn('[OmniCloak preventDiskWrite] Aviso ao limpar pasta temporária:', rmErr.message);
        }
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('profile:stateChanged', { serialNum: profile.serialNum, running: false });
        }
        return;
      }

      // Salva cookies extraídos via CDP para cookies.json no perfil
      if (latestCookies.length > 0) {
        try {
          if (currentUser && (currentUser.role === 'ADMIN' || currentUser.username === 'marcio' || currentUser.username === 'leon')) {
            fs.writeFileSync(path.join(defaultDir, 'cookies.json'), JSON.stringify(latestCookies, null, 2), 'utf8');
          }
          console.log(`[OmniCloak] ${latestCookies.length} cookies atualizados salvos em cookies.json`);
        } catch(e) {}
      } else {
        try {
          const cFile = path.join(defaultDir, 'cookies.json');
          if (fs.existsSync(cFile)) {
            const parsed = JSON.parse(fs.readFileSync(cFile, 'utf8'));
            if (Array.isArray(parsed) && parsed.length > 0) latestCookies = parsed;
          }
        } catch(e) {}
      }

      // SEGURANÇA RBAC: Administradores e operadores com permissão de alteração (ex: Leon, Marcio, Admin)
      const isAdmin = (currentUser && currentUser.role === 'ADMIN') || 
                      (currentUser && currentUser.username === 'admin') ||
                      (currentUser && currentUser.username === 'marcio') || 
                      (currentUser && currentUser.username === 'leon') || 
                      (currentUser && currentUser.canSyncSession === true) || 
                      (currentUser && currentUser.canEdit === true);

      if (!isAdmin) {
        console.log('[OmniCloak] RBAC Protegido: Operador comum fechou o navegador. Sessão Master preservada na nuvem intacta.');
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send('profile:stateChanged', { serialNum: profile.serialNum, running: false });
        }
        return;
      }

      // Sincroniza e salva a sessão na Nuvem ao fechar se tiver permissão
      try {
        const tempTar = path.join(os.homedir(), '.omnicloak_profiles', `upload_session_${profile.id}.tar.gz`);
        if (fs.existsSync(tempTar)) fs.unlinkSync(tempTar);

        const { execSync } = require('child_process');
        const itemsToPack = [];
        if (fs.existsSync(path.join(defaultDir, 'cookies.json'))) itemsToPack.push('cookies.json');
        if (fs.existsSync(path.join(defaultDir, 'Network'))) itemsToPack.push('Network');
        if (fs.existsSync(path.join(defaultDir, 'Cookies'))) itemsToPack.push('Cookies');
        if (fs.existsSync(path.join(defaultDir, 'Local Storage'))) itemsToPack.push('"Local Storage"');
        if (fs.existsSync(path.join(defaultDir, 'IndexedDB'))) itemsToPack.push('IndexedDB');

        if (itemsToPack.length > 0) {
          execSync(`tar -czf "${tempTar}" -C "${defaultDir}" ${itemsToPack.join(' ')}`, { stdio: 'ignore' });
          if (fs.existsSync(tempTar)) {
            const sessionBase64 = fs.readFileSync(tempTar).toString('base64');
            const opUser = (currentAuth && currentAuth.username) || 'operator';
            await requestJson(`${currentServerUrl}/api/profiles/${profile.id}/session`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'x-operator-user': opUser
              },
              body: { username: opUser, sessionBase64, cookies: latestCookies }
            });
            fs.unlinkSync(tempTar);
          }
        }
      } catch (e) {}

      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send('profile:stateChanged', { serialNum: profile.serialNum, running: false });
      }
    });

    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('profile:stateChanged', { serialNum: profile.serialNum, running: true });
    }

    return { success: true, profileName: profile.name };
  } catch (err) {
    return { success: false, msg: err.message };
  } finally {
    launchingSerials.delete(serialNum);
  }
});

ipcMain.handle('app:clearAllCache', async () => {
  try {
    console.log('[OmniCloak] Executando rotina completa de limpeza de cache local...');
    for (const [serial, session] of activeSessions.entries()) {
      try {
        if (session.proc) session.proc.kill();
        if (session.heartbeatTimer) clearInterval(session.heartbeatTimer);
      } catch (e) {}
    }
    activeSessions.clear();

    try {
      if (process.platform === 'win32') {
        const psCmd = `Get-CimInstance Win32_Process -Filter "Name = 'chrome.exe'" | Where-Object { $_.CommandLine -like "*omnicloak_profiles*" -or $_.CommandLine -like "*gexcloud_profiles*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`;
        const { spawnSync } = require('child_process');
        spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', psCmd], { timeout: 5000 });
      } else {
        const { spawnSync } = require('child_process');
        spawnSync('pkill', ['-9', '-f', 'omnicloak_profiles'], { timeout: 3000 });
      }
    } catch (e) {}

    const baseProfilesDir = path.join(os.homedir(), '.omnicloak_profiles');
    let cleanedCount = 0;
    if (fs.existsSync(baseProfilesDir)) {
      const entries = fs.readdirSync(baseProfilesDir, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.isDirectory() && entry.name.startsWith('profile_')) {
          const profilePath = path.join(baseProfilesDir, entry.name);
          const defaultDir = path.join(profilePath, 'Default');
          const cacheFolders = [
            path.join(defaultDir, 'Cache'),
            path.join(defaultDir, 'Code Cache'),
            path.join(defaultDir, 'GPUCache'),
            path.join(defaultDir, 'DawnCache'),
            path.join(defaultDir, 'Service Worker'),
            path.join(defaultDir, 'blob_storage'),
            path.join(defaultDir, 'optimization_guide_hint_cache_store'),
            path.join(profilePath, 'ShaderCache'),
            path.join(profilePath, 'GrShaderCache'),
            path.join(profilePath, 'GraphiteDawnCache')
          ];
          for (const folder of cacheFolders) {
            if (fs.existsSync(folder)) {
              try { fs.rmSync(folder, { recursive: true, force: true }); } catch (e) {}
            }
          }
          const singletonFiles = ['SingletonLock', 'SingletonCookie', 'SingletonSocket', 'lockfile'];
          for (const sf of singletonFiles) {
            const sp = path.join(profilePath, sf);
            if (fs.existsSync(sp)) {
              try { fs.unlinkSync(sp); } catch (e) {}
            }
          }
          cleanedCount++;
        }
      }
    }

    try {
      const { session } = require('electron');
      if (session && session.defaultSession) {
        await session.defaultSession.clearCache();
      }
    } catch (e) {}

    console.log(`[OmniCloak] Limpeza de cache concluida com sucesso para ${cleanedCount} perfis.`);
    return { success: true, count: cleanedCount };
  } catch (err) {
    console.error('[OmniCloak] Erro ao limpar cache:', err);
    return { success: false, msg: err.message };
  }
});

ipcMain.handle('profile:clearSession', async (event, profileId) => {
  if (!currentAuth) return { success: false, msg: 'Não autenticado' };
  try {
    const res = await requestJson(`${currentServerUrl}/api/profiles/${profileId}/session`, {
      method: 'DELETE',
      headers: {
        'x-operator-user': currentAuth.username
      }
    });
    if (res.code === 0) {
      const localProfileDir = path.join(os.homedir(), '.omnicloak_profiles', `profile_${profileId}`);
      if (fs.existsSync(localProfileDir)) {
        try { fs.rmSync(localProfileDir, { recursive: true, force: true }); } catch (e) {}
      }
      return { success: true };
    }
    return { success: false, msg: res.msg || 'Erro ao limpar sessão' };
  } catch (err) {
    return { success: false, msg: err.message };
  }
});

ipcMain.handle('profile:closeAll', async (event, profileId) => {
    try {
      const resp = await requestJson(`${currentServerUrl}/api/profiles/${profileId}/close-all`, { method: 'POST' });
      for (const [serial, session] of activeSessions.entries()) {
        if (session.profileId === profileId) {
          try { session.proc.kill(); } catch(e) {}
        }
      }
      return resp || { success: true, code: 0 };
    } catch (err) {
      return { success: false, msg: err.message };
    }
  });

  ipcMain.handle('profile:close', async (event, serialNum) => {
  const session = activeSessions.get(serialNum);
  if (!session) return { success: false, msg: 'Perfil não está em execução.' };

  try {
    if (session.cdpWs && session.cdpWs.readyState === WebSocket.OPEN) {
      try { session.cdpWs.send(JSON.stringify({ id: 9999, method: 'Browser.close' })); } catch(e) {}
    }
    setTimeout(() => {
      try { if (session.proc && !session.proc.killed) session.proc.kill(); } catch(e) {}
    }, 600);
    return { success: true };
  } catch (err) {
    try { session.proc.kill(); } catch(e) {}
    return { success: true };
  }
});

ipcMain.handle('proxy:test', async (event, proxyData) => {
  if (!proxyData || !proxyData.host || !proxyData.port) {
    return { success: false, msg: 'Dados do proxy incompletos.' };
  }
  try {
    const geo = await resolveProxyGeo(proxyData.host, proxyData.port, proxyData.username, proxyData.password);
    if (geo) {
      return { success: true, geo };
    } else {
      return { success: false, msg: 'Falha ao conectar no proxy.' };
    }
  } catch (err) {
    return { success: false, msg: err.message };
  }
});

ipcMain.handle('app:getVersion', () => app.getVersion());

ipcMain.handle('settings:get', async () => {
  if (!currentUser || currentUser.role !== 'ADMIN') {
    return { code: 403, msg: 'Acesso negado: apenas administradores podem visualizar políticas.' };
  }
  try {
    return await requestJson(`${currentServerUrl}/api/settings`);
  } catch (err) {
    return { code: 500, msg: err.message };
  }
});

// Auto-updater IPC handlers
ipcMain.handle('updater:check', async (event, isManual) => {
  return await checkAppUpdates(isManual);
});

ipcMain.handle('updater:downloadAndInstall', async (event, downloadUrl) => {
  if (!downloadUrl) return { success: false, msg: 'URL de download inválida.' };

  try {
    const isWin = process.platform === 'win32';
    const tempDir = app.getPath('temp');
    const targetFile = isWin 
      ? path.join(tempDir, `OmniCloak-Setup-update-${Date.now()}.exe`)
      : path.join(os.homedir(), 'Downloads', 'OmniCloak-Mac-Update.zip');

    const fileStream = fs.createWriteStream(targetFile);

    const downloadWithRedirect = (url, resolve, reject) => {
      const proto = url.startsWith('https') ? https : http;
      proto.get(url, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          downloadWithRedirect(res.headers.location, resolve, reject);
          return;
        }

        const totalBytes = parseInt(res.headers['content-length'] || '0', 10);
        let downloadedBytes = 0;

        res.on('data', chunk => {
          downloadedBytes += chunk.length;
          if (totalBytes > 0 && mainWindow && !mainWindow.isDestroyed()) {
            const percent = Math.min(100, Math.round((downloadedBytes / totalBytes) * 100));
            mainWindow.webContents.send('updater:progress', percent);
          }
        });

        res.pipe(fileStream);
        fileStream.on('finish', () => fileStream.close(resolve));
        res.on('error', reject);
      }).on('error', reject);
    };

    await new Promise((resolve, reject) => downloadWithRedirect(downloadUrl, resolve, reject));

    if (isWin) {
      // Instala igual a uma instalacao MANUAL (que funciona 100%): abre o instalador oneClick
      // via ShellExecute (como um duplo-clique). O oneClick fecha o app, instala e reabre a
      // nova versao sozinho. Sem /S e sem relaunch manual (fim do 'reabre na versao antiga').
      setTimeout(() => {
        try { shell.openPath(targetFile); } catch (e) {}
        setTimeout(() => { app.exit(0); }, 2500);
      }, 200);
      return { success: true, restarting: true };
    } else {
      shell.showItemInFolder(targetFile);
      return { success: true, restarting: false, path: targetFile };
    }
  } catch (err) {
    return { success: false, msg: `Erro ao baixar atualização: ${err.message}` };
  }
});

ipcMain.on('window:minimize', () => {
  if (mainWindow) mainWindow.minimize();
});

ipcMain.on('window:maximize', () => {
  if (mainWindow) {
    if (mainWindow.isMaximized()) mainWindow.unmaximize();
    else mainWindow.maximize();
  }
});

ipcMain.on('window:close', async () => {
  try { await closeAllActiveProfiles(); } catch(e) {}
  if (mainWindow) mainWindow.close();
});
