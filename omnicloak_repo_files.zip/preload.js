const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('gexApi', {
  getSavedAuth: () => ipcRenderer.invoke('auth:getSaved'),
  login: (credentials) => ipcRenderer.invoke('auth:login', credentials),
  logout: () => ipcRenderer.invoke('auth:logout'),
  getProfiles: () => ipcRenderer.invoke('profiles:list'),
  testProxy: (proxyData) => ipcRenderer.invoke('proxy:test', proxyData),
  launchProfile: (serialNum) => ipcRenderer.invoke('profile:launch', serialNum),
  closeProfile: (serialNum) => ipcRenderer.invoke('profile:close', serialNum),
  clearProfileSession: (profileId) => ipcRenderer.invoke('profile:clearSession', profileId),
  clearAllCache: () => ipcRenderer.invoke('app:clearAllCache'),
  closeAllSessions: (profileId) => ipcRenderer.invoke('profile:closeAll', profileId),
  minimizeWindow: () => ipcRenderer.send('window:minimize'),
  maximizeWindow: () => ipcRenderer.send('window:maximize'),
  closeWindow: () => ipcRenderer.send('window:close'),
  getAppVersion: () => ipcRenderer.invoke('app:getVersion'),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  
  // Auto-Updater
  checkForUpdates: (isManual) => ipcRenderer.invoke('updater:check', isManual),
  downloadAndInstallUpdate: (downloadUrl) => ipcRenderer.invoke('updater:downloadAndInstall', downloadUrl),
  onUpdateAvailable: (callback) => ipcRenderer.on('updater:available', (event, data) => callback(data)),
  onUpdateProgress: (callback) => ipcRenderer.on('updater:progress', (event, percent) => callback(percent)),
  onUpdateUpToDate: (callback) => ipcRenderer.on('updater:upToDate', (event, data) => callback(data)),
  onProfileStateChange: (callback) => {
    ipcRenderer.on('profile:stateChanged', (event, data) => callback(data));
  },
  onAuthKicked: (callback) => {
    ipcRenderer.on('auth:kicked', (event, msg) => callback(msg));
  }
});
