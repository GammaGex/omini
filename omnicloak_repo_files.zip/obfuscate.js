const fs = require('fs');
const path = require('path');
const JavaScriptObfuscator = require('javascript-obfuscator');

console.log('--- Iniciando Ofuscação Blindada do OmniCloak ---');

const srcPath = path.join(__dirname, 'main.js');
const backupPath = path.join(__dirname, 'main.raw.js');

if (!fs.existsSync(backupPath)) {
  fs.copyFileSync(srcPath, backupPath);
}

const rawCode = fs.readFileSync(backupPath, 'utf8');

console.log('Ofuscando main.js com RC4 String Array, Control Flow Flattening e Anti-Debug...');

const obfuscated = JavaScriptObfuscator.obfuscate(rawCode, {
  compact: true,
  controlFlowFlattening: true,
  controlFlowFlatteningThreshold: 0.5,
  deadCodeInjection: true,
  deadCodeInjectionThreshold: 0.2,
  debugProtection: false, // leave false so it doesn't interfere with legitimate child processes
  disableConsoleOutput: false,
  identifierNamesGenerator: 'hexadecimal',
  log: false,
  numbersToExpressions: true,
  renameGlobals: false,
  selfDefending: false, // selfDefending can break Node/Electron eval hooks
  simplify: true,
  splitStrings: true,
  splitStringsChunkLength: 10,
  stringArray: true,
  stringArrayCallsTransform: true,
  stringArrayCallsTransformThreshold: 0.75,
  stringArrayEncoding: ['rc4'],
  stringArrayIndexShift: true,
  stringArrayRotate: true,
  stringArrayShuffle: true,
  stringArrayWrappersCount: 2,
  stringArrayWrappersChainedCalls: true,
  stringArrayWrappersParametersMaxCount: 4,
  stringArrayWrappersType: 'function',
  stringArrayThreshold: 0.8,
  target: 'node'
});

fs.writeFileSync(srcPath, obfuscated.getObfuscatedCode(), 'utf8');
console.log('✅ main.js ofuscado e blindado com sucesso!');
